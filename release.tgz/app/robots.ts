import { MetadataRoute } from "next";
import { isPublicIndexingEnabled } from "@/lib/seo/environment";

export default function robots(): MetadataRoute.Robots {
  const publicIndexing = isPublicIndexingEnabled();

  if (!publicIndexing) {
    return {
      rules: [
        {
          userAgent: "*",
          disallow: "/",
        },
      ],
      sitemap: "https://www.dgeniussolutions.com/sitemap.xml",
      host: "https://www.dgeniussolutions.com",
    };
  }

  return {
    rules: [
      {
        userAgent: "*",
        allow: "/",
        disallow: ["/api/", "/admin/", "/wp-admin/", "/wp-login.php"],
      },
    ],
    sitemap: "https://www.dgeniussolutions.com/sitemap.xml",
    host: "https://www.dgeniussolutions.com",
  };
}
