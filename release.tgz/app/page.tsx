import { Metadata } from "next";
import Image from "next/image";
import Link from "next/link";
import { Fragment } from "react";
import { buildPageMetadata } from "@/lib/seo/metadata";
import { organizationSchema, webPageSchema, breadcrumbSchema } from "@/lib/schema/builders";
import { JsonLd } from "@/components/seo/JsonLd";
import { loadContentBlocks } from "@/lib/nextjs/content-blocks";
import type { ContentBlock, HeadingBlock, ImageBlock, ParagraphBlock } from "@/lib/content/types";
import styles from "./page.module.css";

export const metadata: Metadata = buildPageMetadata({
  title: "Digital Marketing Agency in Mumbai | D'Genius Solutions",
  description: "D'Genius Solutions is a full service digital marketing agency in Mumbai offering connected search, website development, social media, performance marketing, branding and AI-led creative production.",
  path: "/",
  canonicalPath: "/",
  indexable: true,
});

const orgId = "https://www.dgeniussolutions.com/#organization";

const schemaBlocks = [
  organizationSchema({
    name: "D'Genius Solutions",
    url: "https://www.dgeniussolutions.com",
    id: orgId,
  }),
  webPageSchema({
    name: "Digital Marketing Agency in Mumbai | D'Genius Solutions",
    description: "D'Genius Solutions is a full service digital marketing agency in Mumbai offering connected search, website development, social media, performance marketing, branding and AI-led creative production.",
    path: "/",
    organizationId: orgId,
    type: "WebPage",
  }),
  breadcrumbSchema([
    { name: "Home", path: "/" },
  ]),
];

function isHeading(block: ContentBlock, text?: string, level?: number): block is HeadingBlock {
  if (block.type !== "heading") return false;
  if (text !== undefined && block.text !== text) return false;
  if (level !== undefined && block.level !== level) return false;
  return true;
}

function isParagraph(block: ContentBlock): block is ParagraphBlock {
  return block.type === "paragraph";
}

function getHeadingText(block: ContentBlock): string {
  return isHeading(block) ? block.text : "";
}

function getParagraphText(block: ContentBlock): string {
  return isParagraph(block) ? (block.content || []).map((s) => s.text || "").join("").trim() : "";
}

function renderParagraphContent(block: ParagraphBlock): React.ReactNode {
  const content = block.content || [];
  if (content.length === 0) return null;

  return content.map((segment, idx) => {
    const text = segment.text || "";
    if (!text) return null;

    let node: React.ReactNode = text;
    if (segment.strong) {
      node = <strong>{node}</strong>;
    }
    if (segment.emphasis) {
      node = <em>{node}</em>;
    }

    if (!segment.href) {
      return <Fragment key={idx}>{node}</Fragment>;
    }

    const href = segment.href;
    try {
      if (href.startsWith("https://www.dgeniussolutions.com/") || href.startsWith("http://www.dgeniussolutions.com/")) {
        const url = new URL(href);
        const relativeHref = url.pathname + url.search + url.hash;
        return (
          <Link key={idx} href={relativeHref}>
            {node}
          </Link>
        );
      }
      if (href.startsWith("/")) {
        return (
          <Link key={idx} href={href}>
            {node}
          </Link>
        );
      }
    } catch {
      // Fall through to <a>
    }

    return (
      <a key={idx} href={href} target="_blank" rel="noopener noreferrer">
        {node}
      </a>
    );
  });
}

function findFirst<T extends ContentBlock>(
  blocks: ContentBlock[],
  predicate: (block: ContentBlock) => boolean,
): T | undefined {
  const found = blocks.find(predicate);
  if (found && predicate(found)) return found as T;
  return undefined;
}

function renderBlock(block: ContentBlock, index: number): React.ReactNode {
  const key = `block-${index}`;

  switch (block.type) {
    case "paragraph": {
      const text = getParagraphText(block);
      if (!text) return null;
      const isSmallLabel = /^(\d{2}|Ready To Fix The Gaps\?)$/.test(text);
      return (
        <p key={key} className={isSmallLabel ? styles.label : styles.paragraph}>
          {renderParagraphContent(block as ParagraphBlock)}
        </p>
      );
    }
    case "heading": {
      const text = getHeadingText(block);
      const level = block.level;
      const Tag = `h${level}` as "h2" | "h3" | "h4";
      const className = level === 2 ? styles.h2 : level === 3 ? styles.h3 : styles.h4;
      return <Tag key={key} className={className}>{text}</Tag>;
    }
    case "image": {
      const src = (block as ImageBlock).src || "";
      if (src.startsWith("data:image/svg+xml;base64,")) {
        const decoded = Buffer.from(src.split(",")[1] || "", "base64").toString();
        if (decoded.includes('width="1"') && decoded.includes('height="1"')) return null;
      }
      const imgBlock = block as ImageBlock;
      return (
        <figure key={key} className={styles.figure}>
          <Image
            src={src}
            alt={imgBlock.alt}
            width={imgBlock.width ?? 600}
            height={imgBlock.height ?? 400}
            className={styles.image}
            loading="lazy"
          />
        </figure>
      );
    }
    default:
      return null;
  }
}

function getSectionBlockRange(blocks: ContentBlock[], sectionId: string): { start: number; end: number } | null {
  const startIndex = blocks.findIndex((b) => {
    if (b.type !== "heading") return false;
    switch (sectionId) {
      case "hero":
        return b.level === 1 && b.text === "Full Service Digital Marketing Agency In Mumbai";
      case "trusted-by":
        return b.text === "Trusted by brands across finance, retail, education, healthcare, consumer and technology categories.";
      case "awards":
        return b.text === "Recognized for SEO, Content & Performance Marketing";
      case "services":
        return b.text === "One team for search, web, creative, performance and AI production.";
      case "portfolio":
        return b.text === "AI-Led Creative Portfolio";
      case "case-studies":
        return b.text === "SEO, Website And Digital Growth Case Studies";
      case "testimonials":
        return b.text === "Trusted By Brands Worldwide";
      case "search-authority":
        return b.text === "Built For Google Search, AI Answers And Voice Discovery";
      case "industries":
        return b.text === "Industries We Help Grow";
      case "why-dgs":
        return b.text === "Why Brands Choose D’Genius Solutions";
      case "cta":
        return b.text === "Let us audit your brand, website, search visibility and campaign flow.";
      default:
        return false;
    }
  });

  if (startIndex === -1) return null;

  const endIndex = blocks.findIndex((b, i) => {
    if (i <= startIndex) return false;
    if (!isHeading(b)) return false;
    return b.level === 2;
  });

  let sectionEnd = endIndex === -1 ? blocks.length : endIndex;
  if (sectionEnd > startIndex + 1 && blocks[sectionEnd - 1].type === "paragraph") {
    sectionEnd--;
  }

  return { start: startIndex, end: sectionEnd };
}

function renderSection(sectionId: string, blocks: ContentBlock[]): React.ReactNode {
  const range = getSectionBlockRange(blocks, sectionId);
  if (!range) return null;

  const sectionBlocks = blocks.slice(range.start, range.end);

  switch (sectionId) {
    case "hero":
      return <HeroSection blocks={sectionBlocks} />;
    case "trusted-by":
      return <TrustedBySection blocks={sectionBlocks} />;
    case "awards":
      return <AwardsSection blocks={sectionBlocks} />;
    case "services":
      return <ServicesSection blocks={sectionBlocks} />;
    case "portfolio":
      return <PortfolioSection blocks={sectionBlocks} />;
    case "case-studies":
      return <CaseStudiesSection blocks={sectionBlocks} />;
    case "testimonials":
      return <TestimonialsSection blocks={sectionBlocks} />;
    case "search-authority":
      return <SearchAuthoritySection blocks={sectionBlocks} />;
    case "industries":
      return <IndustriesSection blocks={sectionBlocks} />;
    case "why-dgs":
      return <WhyDgsSection blocks={sectionBlocks} />;
    case "cta":
      return <CTASection blocks={sectionBlocks} />;
    default:
      return null;
  }
}

function HeroSection({ blocks }: { blocks: ContentBlock[] }) {
  return (
    <section className={styles.hero}>
      <div className={styles.heroBg} />
      <div className={styles.heroInner}>
        <div className={styles.heroContent}>
          {blocks.map((block, i) => renderBlock(block, i))}
        </div>
      </div>
    </section>
  );
}

function TrustedBySection({ blocks }: { blocks: ContentBlock[] }) {
  return (
    <section className={styles.trustedBy}>
      <div className={styles.container}>
        {blocks.map((block, i) => renderBlock(block, i))}
      </div>
    </section>
  );
}

function AwardsSection({ blocks }: { blocks: ContentBlock[] }) {
  const awards: Array<{ year: string; title: string; desc: string }> = [];
  const used = new Set<number>();
  for (let i = 0; i < blocks.length; i++) {
    const b = blocks[i];
    if (isHeading(b, undefined, 3)) {
      const year = i > 0 && isParagraph(blocks[i - 1]) ? getParagraphText(blocks[i - 1]) : "";
      const desc = i + 1 < blocks.length && isParagraph(blocks[i + 1]) ? getParagraphText(blocks[i + 1]) : "";
      awards.push({ year, title: getHeadingText(b), desc });
      used.add(i);
      if (i > 0 && isParagraph(blocks[i - 1])) used.add(i - 1);
      if (i + 1 < blocks.length && isParagraph(blocks[i + 1])) used.add(i + 1);
    }
  }

  const heading = findFirst<HeadingBlock>(blocks, (b) => isHeading(b, undefined, 2));
  const intro = findFirst<ParagraphBlock>(blocks, (b) => isParagraph(b) && b !== blocks[0]);
  if (heading) used.add(blocks.indexOf(heading));
  if (intro) used.add(blocks.indexOf(intro));

  return (
    <section className={styles.awards}>
      <div className={styles.container}>
        <div className={styles.sectionHeader}>
          <h2 className={styles.sectionTitle}>{heading?.text}</h2>
          <p className={styles.sectionSubtitle}>{getParagraphText(intro || { type: "paragraph", content: [] })}</p>
        </div>
        <div className={styles.awardsGrid}>
          {awards.map((award, i) => (
            <article key={i} className={styles.awardCard}>
              <span className={styles.awardYear}>{award.year}</span>
              <h3 className={styles.awardTitle}>{award.title}</h3>
              <p className={styles.awardDesc}>{award.desc}</p>
            </article>
          ))}
        </div>
        {blocks.map((block, i) => (used.has(i) ? null : renderBlock(block, i)))}
      </div>
    </section>
  );
}

function ServicesSection({ blocks }: { blocks: ContentBlock[] }) {
  return (
    <section className={styles.services}>
      <div className={styles.container}>
        {blocks.map((block, i) => renderBlock(block, i))}
      </div>
    </section>
  );
}

function PortfolioSection({ blocks }: { blocks: ContentBlock[] }) {
  return (
    <section className={styles.portfolio}>
      <div className={styles.container}>
        {blocks.map((block, i) => renderBlock(block, i))}
      </div>
    </section>
  );
}

function CaseStudiesSection({ blocks }: { blocks: ContentBlock[] }) {
  return (
    <section className={styles.caseStudies}>
      <div className={styles.container}>
        {blocks.map((block, i) => renderBlock(block, i))}
      </div>
    </section>
  );
}

function TestimonialsSection({ blocks }: { blocks: ContentBlock[] }) {
  return (
    <section className={styles.testimonials}>
      <div className={styles.container}>
        {blocks.map((block, i) => renderBlock(block, i))}
      </div>
    </section>
  );
}

function SearchAuthoritySection({ blocks }: { blocks: ContentBlock[] }) {
  return (
    <section className={styles.searchAuthority}>
      <div className={styles.container}>
        {blocks.map((block, i) => renderBlock(block, i))}
      </div>
    </section>
  );
}

function IndustriesSection({ blocks }: { blocks: ContentBlock[] }) {
  const heading = findFirst<HeadingBlock>(blocks, (b) => isHeading(b, undefined, 2));
  const intro = findFirst<ParagraphBlock>(blocks, (b) => isParagraph(b) && b !== blocks[0]);
  const industriesText = findFirst<ParagraphBlock>(blocks, (b) => isParagraph(b) && b !== intro && b !== blocks[0]);
  const used = new Set<number>();
  if (heading) used.add(blocks.indexOf(heading));
  if (intro) used.add(blocks.indexOf(intro));
  if (industriesText) used.add(blocks.indexOf(industriesText));

  return (
    <section className={styles.industries}>
      <div className={styles.container}>
        <div className={styles.sectionHeader}>
          <h2 className={styles.sectionTitle}>{heading?.text}</h2>
          <p className={styles.sectionSubtitle}>{getParagraphText(intro || { type: "paragraph", content: [] })}</p>
        </div>
        <p className={styles.industriesText}>{getParagraphText(industriesText || { type: "paragraph", content: [] })}</p>
        {blocks.map((block, i) => (used.has(i) ? null : renderBlock(block, i)))}
      </div>
    </section>
  );
}

function WhyDgsSection({ blocks }: { blocks: ContentBlock[] }) {
  const items: Array<{ num: string; title: string; desc: string }> = [];
  const used = new Set<number>();
  let current: { num: string; title: string; desc: string } | null = null;

  for (let i = 0; i < blocks.length; i++) {
    const b = blocks[i];
    if (isParagraph(b) && /^\d{2}$/.test(getParagraphText(b))) {
      if (current) items.push(current);
      current = { num: getParagraphText(b), title: "", desc: "" };
      used.add(i);
    } else if (isHeading(b, undefined, 3) && current) {
      current.title = getHeadingText(b);
      used.add(i);
    } else if (isParagraph(b) && current && !current.desc) {
      current.desc = getParagraphText(b);
      used.add(i);
    }
  }
  if (current) items.push(current);

  const heading = findFirst<HeadingBlock>(blocks, (b) => isHeading(b, undefined, 2));
  const intro = findFirst<ParagraphBlock>(blocks, (b) => isParagraph(b) && b !== blocks[0]);
  if (heading) used.add(blocks.indexOf(heading));
  if (intro) used.add(blocks.indexOf(intro));

  return (
    <section className={styles.whyDgs}>
      <div className={styles.container}>
        <div className={styles.sectionHeader}>
          <h2 className={styles.sectionTitle}>{heading?.text}</h2>
          <p className={styles.sectionSubtitle}>{getParagraphText(intro || { type: "paragraph", content: [] })}</p>
        </div>
        <div className={styles.whyGrid}>
          {items.map((item, i) => (
            <article key={i} className={styles.whyItem}>
              <span className={styles.whyNum}>{item.num}</span>
              <h3 className={styles.whyTitle}>{item.title}</h3>
              <p className={styles.whyDesc}>{item.desc}</p>
            </article>
          ))}
        </div>
        {blocks.map((block, i) => (used.has(i) ? null : renderBlock(block, i)))}
      </div>
    </section>
  );
}

function CTASection({ blocks }: { blocks: ContentBlock[] }) {
  const heading = findFirst<HeadingBlock>(blocks, (b) => isHeading(b, undefined, 2));
  const desc = findFirst<ParagraphBlock>(blocks, (b) => isParagraph(b) && b !== blocks[0]);
  const used = new Set<number>();
  if (heading) used.add(blocks.indexOf(heading));
  if (desc) used.add(blocks.indexOf(desc));

  return (
    <section className={styles.cta}>
      <div className={styles.container}>
        <h2 className={styles.ctaTitle}>{heading?.text}</h2>
        <p className={styles.ctaDesc}>{getParagraphText(desc || { type: "paragraph", content: [] })}</p>
        {blocks.map((block, i) => (used.has(i) ? null : renderBlock(block, i)))}
      </div>
    </section>
  );
}

export default async function HomePage() {
  const blocks = (await loadContentBlocks())["/"]?.blocks || [];

  const sectionIds = [
    "hero",
    "trusted-by",
    "awards",
    "services",
    "portfolio",
    "case-studies",
    "testimonials",
    "search-authority",
    "industries",
    "why-dgs",
    "cta",
  ];

  const sectionRanges = [];
  for (const sectionId of sectionIds) {
    const range = getSectionBlockRange(blocks, sectionId);
    if (range) {
      sectionRanges.push({ id: sectionId, start: range.start, end: range.end });
    }
  }

  sectionRanges.sort((a, b) => a.start - b.start);

  const resolvedRanges = [];
  let lastEnd = 0;
  for (const range of sectionRanges) {
    const start = Math.max(range.start, lastEnd);
    const end = Math.max(start, range.end);
    if (start < end) {
      resolvedRanges.push({ id: range.id, start, end });
      lastEnd = end;
    }
  }

  let renderCursor = 0;

  return (
    <main>
      <article data-migration-content data-wordpress-id={63505}>
        {resolvedRanges.map((range) => {
          const gapBlocks = blocks.slice(renderCursor, range.start);
          const gapStart = renderCursor;
          renderCursor = range.end;
          return (
            <>
              {gapBlocks.map((block, i) => renderBlock(block, gapStart + i))}
              {renderSection(range.id, blocks)}
            </>
          );
        })}
        {blocks.slice(renderCursor).map((block, i) => renderBlock(block, renderCursor + i))}
      </article>

      <JsonLd id="page-jsonld" value={schemaBlocks} />
    </main>
  );
}

