import type { Metadata } from "next";
import { Syne } from "next/font/google";
import { isPublicIndexingEnabled } from "@/lib/seo/environment";
import { SiteHeader } from "@/components/layout/Header";
import { SiteFooter } from "@/components/layout/Footer";
import "./globals.css";

const syne = Syne({
  subsets: ["latin"],
  weight: ["400", "500", "600", "700", "800"],
  display: "swap",
  variable: "--font-syne",
});

export const metadata: Metadata = {
  metadataBase: new URL("https://www.dgeniussolutions.com"),
  title: {
    default: "D'Genius Solutions",
    template: "%s",
  },
  description: "Digital marketing agency in Mumbai offering SEO, AEO, GEO, LLM SEO, AI video production, performance marketing, branding and website development.",
  robots: {
    index: isPublicIndexingEnabled(),
    follow: isPublicIndexingEnabled(),
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" className={syne.variable}>
      <body>
        <SiteHeader />
        <div id="main-content">{children}</div>
        <SiteFooter />
      </body>
    </html>
  );
}
