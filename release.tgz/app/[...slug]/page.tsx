import { notFound } from "next/navigation";
import { Metadata } from "next";
import { loadRouteRegistry, getRouteByPath } from "@/lib/nextjs/routes";
import { loadContentBlocks } from "@/lib/nextjs/content-blocks";
import type { ContentBlock, HeadingBlock } from "@/lib/content/types";
import { slugToPath } from "@/lib/nextjs/path";
import { buildPageMetadata } from "@/lib/seo/metadata";
import { organizationSchema, serviceSchema, breadcrumbSchema, faqSchema, articleSchema } from "@/lib/schema/builders";
import { JsonLd } from "@/components/seo/JsonLd";
import { SemanticContent } from "@/components/content/SemanticContent";
import { assertProtectedRouteSearchPolicy } from "@/lib/migration/search-policy";
import Link from "next/link";

export async function generateStaticParams() {
  const { routes } = await loadRouteRegistry();
  return routes
    .filter((r) => r.proposedAction === "KEEP_SAME_URL" || r.proposedAction === "PROTECTED")
    .filter((r) => r.path !== "/")
    .map((r) => ({ slug: r.path.split("/").filter(Boolean) }));
}

export async function generateMetadata({ params }: { params: Promise<{ slug?: string[] }> }): Promise<Metadata> {
  const { slug } = await params;
  const path = slugToPath(slug || []);
  const route = await getRouteByPath(path);

  if (!route) {
    return { title: "Not Found" };
  }

  const title = route.title || "Page";
  const description = route.description || "";

  return buildPageMetadata({
    title,
    description,
    path,
    canonicalPath: (route.desiredCanonicalPath || route.canonical || path).startsWith("http")
      ? new URL(route.desiredCanonicalPath || route.canonical || path).pathname
      : (route.desiredCanonicalPath || route.canonical || path),
    indexable: route.indexable,
    metadataReview: !description,
  });
}

export default async function DynamicPage({ params }: { params: Promise<{ slug?: string[] }> }) {
  const { slug } = await params;
  const path = slugToPath(slug || []);
  const route = await getRouteByPath(path);

  if (!route) {
    notFound();
  }

  if (!route) {
    notFound();
  }

  if (route.protected) {
    assertProtectedRouteSearchPolicy({
      path: route.path,
      canonicalPath: route.desiredCanonicalPath || route.canonical || route.path,
      indexable: route.indexable,
      includeInSitemap: route.includeInSitemap,
    });
  }

  const blocks = (await loadContentBlocks())[path]?.blocks || [];

  const orgId = "https://www.dgeniussolutions.com/#organization";

  const schemaBlocks = [];

  schemaBlocks.push(organizationSchema({
    name: "D'Genius Solutions",
    url: "https://www.dgeniussolutions.com",
    id: orgId,
  }));

  if (route.wordpressType === "service") {
    schemaBlocks.push(serviceSchema({
      name: route.title || "",
      description: route.description || "",
      path,
      providerId: orgId,
    }));
  }

  const breadcrumbs = buildBreadcrumbs(path, route);
  if (breadcrumbs.length > 0) {
    schemaBlocks.push(breadcrumbSchema(breadcrumbs));
  }

  const pageFaqs = extractFaqsFromBlocks(blocks);
  if (pageFaqs.length > 0) {
    schemaBlocks.push(faqSchema(pageFaqs));
  }

  if (route.wordpressType === "post") {
    schemaBlocks.push(articleSchema({
      headline: route.title || "",
      description: route.description || "",
      path,
      datePublished: route.date || route.modified,
      dateModified: route.modified,
      publisherId: orgId,
    }));
  }

  const pageH1 = route.h1 || route.title || "Page";
  const isH1 = (b: ContentBlock): b is HeadingBlock => b.type === "heading" && b.level === 1;
  const contentBlocks = blocks.filter((b) => !isH1(b));

  return (
    <main className="page-main">
      {breadcrumbs.length > 0 && (
        <nav aria-label="Breadcrumb" className="page-breadcrumbs">
          <ol>
            {breadcrumbs.map((item, i) => (
              <li key={item.path}>
                {i > 0 && <span className="page-breadcrumbs__sep">/</span>}
                {i === breadcrumbs.length - 1 ? (
                  <span aria-current="page">{item.name}</span>
                ) : (
                  <Link href={item.path}>{item.name}</Link>
                )}
              </li>
            ))}
          </ol>
        </nav>
      )}

      <article data-migration-content data-wordpress-id={route.wordpressId}>
        <h1>{pageH1}</h1>
        <SemanticContent blocks={contentBlocks} />
      </article>

      <JsonLd id="page-jsonld" value={schemaBlocks} />
    </main>
  );
}

function extractFaqsFromBlocks(blocks: ContentBlock[]) {
  return blocks
    .filter((b): b is Extract<ContentBlock, { type: "faq" }> => b.type === "faq")
    .flatMap((b) => (b.items || []).map((item) => ({
      question: item.question,
      answer: (item.answer || [{ text: "" }]).map((span) => span.text).join(""),
    })));
}

function buildBreadcrumbs(path: string, route: { path: string; wordpressType: string; title: string | null }) {
  const segments = path.split("/").filter(Boolean);
  const crumbs = [{ name: "Home", path: "/" }];

  if (route.wordpressType === "service" && segments[0] === "services") {
    crumbs.push({ name: "Services", path: "/our-services/" });
    crumbs.push({ name: route.title || "Service", path });
  } else if (route.wordpressType === "post" && segments[0] === "blogs") {
    crumbs.push({ name: "Blogs", path: "/blogs/" });
    crumbs.push({ name: route.title || "Post", path });
  } else if (path === "/") {
    return [];
  } else {
    let built = "";
    for (let i = 0; i < segments.length; i++) {
      built += "/" + segments[i];
      const name = segments[i].replace(/-/g, " ").replace(/\b\w/g, (c) => c.toUpperCase());
      crumbs.push({ name, path: built + "/" });
    }
  }

  return crumbs;
}
