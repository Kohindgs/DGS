import { MetadataRoute } from "next";
import { getIndexableRoutes } from "@/lib/nextjs/routes";

export default async function sitemap(): Promise<MetadataRoute.Sitemap> {
  const routes = await getIndexableRoutes();

  const items = routes
    .filter((r) => r.includeInSitemap)
    .map((r) => {
      const canonical = r.desiredCanonicalPath || r.canonical || r.path;
      const url = canonical.startsWith("http")
        ? canonical
        : `https://www.dgeniussolutions.com${canonical}`;

      return {
        url,
        lastModified: r.modified ? new Date(r.modified) : new Date(),
        changeFrequency: "weekly" as const,
        priority: r.protected ? 1.0 : 0.8,
      };
    });

  return items;
}
