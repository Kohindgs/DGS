import type { WorkSystem } from "@/lib/work/types";

export type PortfolioMediaType = "image" | "video";
export type PortfolioVerificationStatus =
  | "public-evidence-only"
  | "authenticated-wordpress"
  | "explicit-review";

export type PortfolioItem = {
  id: string;
  slug: string;
  title: string;
  workSystem: Exclude<WorkSystem, "case-study">;
  client?: string;
  category?: string;
  mediaType: PortfolioMediaType;
  thumbnail: string;
  media: string;
  poster?: string;
  alt: string;
  caption?: string;
  order?: number;
  featured?: boolean;
  year?: number;
  sourceWordPressId?: number;
  sourceEnviraGalleryId?: number;
  sourceEnviraMediaId?: number;
  verificationStatus: PortfolioVerificationStatus;
};

export type PortfolioCategory = {
  slug: string;
  label: string;
  workSystem: Exclude<WorkSystem, "case-study">;
  order?: number;
};
