module.exports=[98421,a=>{"use strict";var b=a.i(7997);a.s(["default",0,function({children:a}){return(0,b.jsx)("html",{lang:"en",children:(0,b.jsx)("body",{children:a})})},"metadata",0,{title:"DGS Next.js App",description:"A beautiful demo page built with Next.js"}])},46122,a=>{a.n(a.i(98421))}];

//# sourceMappingURL=app_layout_jsx_181co3-._.js.map