module.exports=[43392,a=>{"use strict";var b=a.i(87924),c=a.i(72131);a.s(["default",0,function(){return(0,c.useEffect)(()=>{window.dgsScrollY=0,window.dgsLockScroll=function(){window.dgsScrollY=window.scrollY||document.documentElement.scrollTop||0,document.documentElement.style.overflow="hidden",document.body.style.overflow="hidden",document.body.style.position="fixed",document.body.style.top="-"+window.dgsScrollY+"px",document.body.style.left="0",document.body.style.right="0",document.body.style.width="100%"},window.dgsUnlockScroll=function(){var a=window.dgsScrollY||0;document.documentElement.style.overflow="",document.body.style.overflow="",document.body.style.position="",document.body.style.top="",document.body.style.left="",document.body.style.right="",document.body.style.width="",window.scrollTo(0,a)},window.dgsToggle=function(){var a=document.getElementById("dgsNav"),b=document.getElementById("dgsTrigLabel");if(a){var c=!a.classList.contains("nav-open");a.classList.toggle("nav-open",c),c?window.dgsLockScroll():window.dgsUnlockScroll(),b&&(b.textContent=c?"CLOSE":"MENU")}},window.dgsSvc=function(){var a=document.getElementById("dgsSvcItem"),b=document.getElementById("dgsSub");if(a&&b){var c=!a.classList.contains("svc-open");a.classList.toggle("svc-open",c),b.classList.toggle("open",c)}},window.dgsOpenTalkPopup=function(a){a&&a.preventDefault();var b=document.getElementById("dgsTalkPopup"),c=document.getElementById("dgsNav"),d=document.getElementById("dgsTrigLabel");b&&(c&&c.classList.contains("nav-open")&&(c.classList.remove("nav-open"),d&&(d.textContent="MENU"),window.dgsUnlockScroll()),b.classList.add("is-open"),b.setAttribute("aria-hidden","false"),document.documentElement.classList.add("dgs-talk-popup-active"),document.body.classList.add("dgs-talk-popup-active"))},window.dgsCloseTalkPopup=function(){var a=document.getElementById("dgsTalkPopup");a&&(a.classList.remove("is-open"),a.setAttribute("aria-hidden","true"),document.documentElement.classList.remove("dgs-talk-popup-active"),document.body.classList.remove("dgs-talk-popup-active"))};let a=()=>{var a=document.getElementById("dgsBar");a&&a.classList.toggle("scrolled",window.scrollY>40)};window.addEventListener("scroll",a,{passive:!0});let b=a=>{var b=a.target.closest(".dgs-talk-trigger"),c=a.target.closest("[data-dgs-talk-close]");b&&window.dgsOpenTalkPopup(a),c&&window.dgsCloseTalkPopup()};return document.addEventListener("click",b),()=>{window.removeEventListener("scroll",a),document.removeEventListener("click",b)}},[]),(0,b.jsxs)(b.Fragment,{children:[(0,b.jsx)("link",{rel:"preconnect",href:"https://fonts.googleapis.com"}),(0,b.jsx)("link",{rel:"preconnect",href:"https://fonts.gstatic.com",crossOrigin:"anonymous"}),(0,b.jsx)("link",{href:"https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=Manrope:wght@300;400;500;600;700;800&family=Space+Grotesk:wght@400;500;600;700&family=Syne:wght@700;800&display=swap",rel:"stylesheet"}),(0,b.jsx)("div",{dangerouslySetInnerHTML:{__html:`#dgsNav,
#dgsNav *,
#dgsNav *::before,
#dgsNav *::after {
  box-sizing: border-box !important;
  -webkit-font-smoothing: antialiased !important;
}

#dgsNav a,
#dgsNav a:hover,
#dgsNav a:visited,
#dgsNav a:focus,
#dgsNav a:active {
  text-decoration: none !important;
  outline: none !important;
  box-shadow: none !important;
  border: none !important;
}

#dgsNav {
  --acc: #FD5C62;
  --blk: #080808;
  --bdr: rgba(255,255,255,0.08);
  --mut: rgba(255,255,255,0.35);
  --bar: 100px;
}

#dgsBar {
  position: fixed !important;
  top: 0 !important;
  left: 0 !important;
  width: 100% !important;
  height: var(--bar) !important;
  z-index: 99999 !important;
  display: flex !important;
  align-items: center !important;
  justify-content: space-between !important;
  padding: 0 48px !important;
  background: transparent !important;
  background-image: none !important;
  transition: background-color .4s ease !important;
}

#dgsBar.scrolled,
#dgsNav.nav-open #dgsBar {
  background-color: rgba(8,8,8,.93) !important;
  backdrop-filter: blur(14px) !important;
  -webkit-backdrop-filter: blur(14px) !important;
}

#dgsLogo {
  display: flex !important;
  align-items: center !important;
  height: var(--bar) !important;
  flex-shrink: 0 !important;
  text-decoration: none !important;
  background: none !important;
  border: none !important;
  box-shadow: none !important;
}

#dgsLogo img {
  height: 117px !important;
  width: 117px !important;
  object-fit: contain !important;
  display: block !important;
}

#dgsRight {
  display: flex !important;
  align-items: center !important;
  gap: 14px !important;
}

#dgsPill {
  display: inline-flex !important;
  align-items: center !important;
  gap: 8px !important;
  font-family: 'DM Sans', sans-serif !important;
  font-size: 12px !important;
  font-weight: 600 !important;
  letter-spacing: .12em !important;
  text-transform: uppercase !important;
  color: #fff !important;
  background-color: #FD5C62 !important;
  background-image: none !important;
  padding: 11px 22px !important;
  border-radius: 100px !important;
  border: none !important;
  box-shadow: none !important;
  white-space: nowrap !important;
  cursor: pointer !important;
  transition: transform .3s ease, box-shadow .3s ease !important;
}

#dgsPill:hover {
  transform: scale(1.04) !important;
  box-shadow: 0 0 22px rgba(253,92,98,.5) !important;
  color: #fff !important;
}

#dgsPill svg {
  width: 13px;
  height: 13px;
  stroke: #fff;
  fill: none;
  stroke-width: 2;
  flex-shrink: 0;
}

#dgsTrig {
  display: flex !important;
  align-items: center !important;
  gap: 10px !important;
  background: transparent !important;
  background-color: transparent !important;
  background-image: none !important;
  border: 1px solid rgba(255,255,255,.22) !important;
  border-radius: 100px !important;
  padding: 10px 18px !important;
  cursor: pointer !important;
  box-shadow: none !important;
  outline: none !important;
  user-select: none !important;
  -webkit-user-select: none !important;
  transition: border-color .3s, background-color .3s !important;
}

#dgsTrig:hover {
  background-color: rgba(255,255,255,.06) !important;
  border-color: rgba(255,255,255,.4) !important;
}

#dgsLines {
  display: flex !important;
  flex-direction: column !important;
  gap: 4px !important;
  width: 20px !important;
  pointer-events: none !important;
}

#dgsLines em {
  display: block !important;
  height: 1.5px !important;
  width: 100% !important;
  background-color: #ffffff !important;
  border-radius: 2px !important;
  font-style: normal !important;
  transition: transform .42s cubic-bezier(.76,0,.24,1),
              opacity .42s ease,
              width .42s ease !important;
}

#dgsLines em:nth-child(2) {
  width: 65% !important;
}

#dgsNav.nav-open #dgsLines em:nth-child(1) {
  transform: translateY(5.5px) rotate(45deg) !important;
  width: 100% !important;
}

#dgsNav.nav-open #dgsLines em:nth-child(2) {
  opacity: 0 !important;
  transform: scaleX(0) !important;
}

#dgsNav.nav-open #dgsLines em:nth-child(3) {
  transform: translateY(-5.5px) rotate(-45deg) !important;
}

#dgsTrigLabel {
  font-family: 'DM Sans', sans-serif !important;
  font-size: 11px !important;
  font-weight: 600 !important;
  letter-spacing: .18em !important;
  text-transform: uppercase !important;
  color: #ffffff !important;
  min-width: 38px !important;
  pointer-events: none !important;
  line-height: 1 !important;
}

#dgsOverlay {
  position: fixed !important;
  top: var(--bar) !important;
  left: 0 !important;
  right: 0 !important;
  bottom: 0 !important;
  height: calc(100vh - var(--bar)) !important;
  height: calc(100dvh - var(--bar)) !important;
  z-index: 99998 !important;
  visibility: hidden !important;
  pointer-events: none !important;
  overflow: hidden !important;
  max-width: 100vw !important;
  overscroll-behavior: contain !important;
}

#dgsNav.nav-open #dgsOverlay {
  visibility: visible !important;
  pointer-events: auto !important;
}

#dgsPanel {
  position: absolute !important;
  inset: 0 !important;
  height: 100% !important;
  background-color: #080808 !important;
  background-image: none !important;
  display: flex !important;
  flex-direction: column !important;
  overflow: hidden !important;
  max-width: 100vw !important;
  transform: translateY(-100%) !important;
  transition: transform .8s cubic-bezier(.76,0,.24,1) !important;
}

#dgsNav.nav-open #dgsPanel {
  transform: translateY(0%) !important;
}

#dgsPanelBody {
  flex: 1 !important;
  display: grid !important;
  grid-template-columns: 1fr 300px !important;
  min-height: 0 !important;
  overflow: hidden !important;
  max-width: 100vw !important;
}

#dgsLinks {
  display: flex !important;
  flex-direction: column !important;
  justify-content: center !important;
  padding: 36px 48px 28px !important;
  border-right: 1px solid var(--bdr) !important;
  overflow: hidden !important;
  max-width: 100% !important;
  min-width: 0 !important;
}

.dg-item {
  border-bottom: 1px solid var(--bdr) !important;
  overflow: hidden !important;
  flex-shrink: 0 !important;
  position: relative !important;
  max-width: 100% !important;
  min-width: 0 !important;
}

#dgsNav.nav-open .dg-item:nth-child(1) .dg-row {
  animation: dgSlideIn .5s .38s both;
}

#dgsNav.nav-open .dg-item:nth-child(2) .dg-row {
  animation: dgSlideIn .5s .43s both;
}

#dgsNav.nav-open .dg-item:nth-child(3) .dg-row {
  animation: dgSlideIn .5s .48s both;
}

#dgsNav.nav-open .dg-item:nth-child(4) .dg-row {
  animation: dgSlideIn .5s .53s both;
}

#dgsNav.nav-open .dg-item:nth-child(5) .dg-row {
  animation: dgSlideIn .5s .58s both;
}

#dgsNav.nav-open .dg-item:nth-child(6) .dg-row {
  animation: dgSlideIn .5s .63s both;
}

#dgsNav.nav-open .dg-item:nth-child(7) .dg-row {
  animation: dgSlideIn .5s .68s both;
}

#dgsNav.nav-open .dg-item:nth-child(8) .dg-row {
  animation: dgSlideIn .5s .73s both;
}

@keyframes dgSlideIn {
  from {
    opacity: 0;
    transform: translateY(24px);
  }

  to {
    opacity: 1;
    transform: translateY(0);
  }
}

.dg-row {
  display: flex !important;
  align-items: center !important;
  justify-content: space-between !important;
  padding: 11px 0 !important;
  cursor: pointer !important;
  text-decoration: none !important;
  background: none !important;
  background-image: none !important;
  border: none !important;
  color: #fff !important;
  width: 100% !important;
  position: relative !important;
}

.dg-lbl {
  font-family: 'Syne', sans-serif !important;
  font-size: clamp(26px, 4vw, 56px) !important;
  font-weight: 700 !important;
  text-transform: uppercase !important;
  color: #ffffff !important;
  letter-spacing: -.02em !important;
  line-height: 1 !important;
  pointer-events: none !important;
  transition: color .28s ease, transform .32s ease !important;
}

.dg-item:hover .dg-lbl {
  color: #FD5C62 !important;
  transform: translateX(5px) !important;
}

.dg-badge {
  width: 32px !important;
  height: 32px !important;
  min-width: 32px !important;
  border-radius: 50% !important;
  border: 1px solid rgba(255,255,255,.14) !important;
  display: flex !important;
  align-items: center !important;
  justify-content: center !important;
  flex-shrink: 0 !important;
  transition: background-color .28s ease, border-color .28s ease !important;
}

.dg-badge svg {
  width: 12px !important;
  height: 12px !important;
  stroke: rgba(255,255,255,.45) !important;
  fill: none !important;
  stroke-width: 1.8 !important;
  pointer-events: none !important;
  transition: stroke .28s ease, transform .35s cubic-bezier(.76,0,.24,1) !important;
}

.dg-item:hover .dg-badge,
.dg-item.svc-open .dg-badge {
  background-color: #FD5C62 !important;
  border-color: #FD5C62 !important;
}

.dg-item:hover .dg-badge svg,
.dg-item.svc-open .dg-badge svg {
  stroke: #fff !important;
  transform: rotate(45deg) !important;
}

.dg-mq {
  overflow: hidden !important;
  height: 0 !important;
  pointer-events: none !important;
  transition: height .38s cubic-bezier(.76,0,.24,1) !important;
}

.dg-item:hover .dg-mq {
  height: 20px !important;
}

.dg-mq-t {
  display: flex !important;
  white-space: nowrap !important;
  animation: dgRun 12s linear infinite !important;
}

.dg-mq-t span {
  font-family: 'DM Sans', sans-serif !important;
  font-size: 10px !important;
  font-weight: 600 !important;
  letter-spacing: .2em !important;
  text-transform: uppercase !important;
  color: #FD5C62 !important;
  padding-right: 40px !important;
  flex-shrink: 0 !important;
  opacity: .85 !important;
}

@keyframes dgRun {
  from {
    transform: translateX(0);
  }

  to {
    transform: translateX(-50%);
  }
}

#dgsSvcItem .dg-badge {
  background-color: rgba(253,92,98,0.12) !important;
  border-color: #FD5C62 !important;
  width: auto !important;
  padding: 0 10px !important;
  border-radius: 6px !important;
  gap: 4px !important;
}

#dgsSvcItem .dg-badge svg {
  stroke: #FD5C62 !important;
}

#dgsSvcItem .dg-badge::after {
  content: 'TAP TO EXPAND' !important;
  font-family: 'DM Sans', sans-serif !important;
  font-size: 8px !important;
  font-weight: 600 !important;
  letter-spacing: .12em !important;
  color: #FD5C62 !important;
  white-space: nowrap !important;
  display: block !important;
}

#dgsSvcItem.svc-open .dg-badge {
  background-color: #FD5C62 !important;
  border-color: #FD5C62 !important;
}

#dgsSvcItem.svc-open .dg-badge svg {
  stroke: #ffffff !important;
  transform: rotate(180deg) !important;
}

#dgsSvcItem.svc-open .dg-badge::after {
  color: #ffffff !important;
}

.dg-sub {
  display: grid !important;
  grid-template-columns: repeat(3,1fr) !important;
  gap: 4px 12px !important;
  max-height: 0 !important;
  opacity: 0 !important;
  overflow: hidden !important;
  padding: 0 !important;
  transform: translateY(-6px) !important;
  transition: max-height .45s cubic-bezier(.76,0,.24,1),
              opacity .25s ease,
              padding .35s ease,
              transform .35s ease !important;
}

.dg-sub.open {
  max-height: 260px !important;
  opacity: 1 !important;
  padding: 4px 0 14px !important;
  transform: translateY(0) !important;
}

.dg-sub a {
  font-family: 'DM Sans', sans-serif !important;
  font-size: 15px !important;
  font-weight: 500 !important;
  color: rgba(255,255,255,.6) !important;
  text-decoration: none !important;
  padding: 6px 0 !important;
  letter-spacing: .02em !important;
  transition: color .2s !important;
  display: block !important;
}

.dg-sub a:hover {
  color: #fff !important;
}

#dgsInfo {
  display: flex !important;
  flex-direction: column !important;
  justify-content: space-between !important;
  padding: 32px !important;
  overflow-y: auto !important;
  background-color: #080808 !important;
}

#dgsNav.nav-open .dg-ib:nth-child(1) {
  animation: dgFadeUp .5s .5s both;
}

#dgsNav.nav-open .dg-ib:nth-child(2) {
  animation: dgFadeUp .5s .56s both;
}

#dgsNav.nav-open .dg-ib:nth-child(3) {
  animation: dgFadeUp .5s .62s both;
}

#dgsNav.nav-open #dgsCtaBtn {
  animation: dgFadeUp .5s .68s both;
}

@keyframes dgFadeUp {
  from {
    opacity: 0;
    transform: translateY(14px);
  }

  to {
    opacity: 1;
    transform: translateY(0);
  }
}

.dg-ib {
  margin-bottom: 26px !important;
}

.dg-lbl2 {
  font-family: 'DM Sans', sans-serif !important;
  font-size: 10px !important;
  font-weight: 600 !important;
  letter-spacing: .22em !important;
  text-transform: uppercase !important;
  color: rgba(255,255,255,.28) !important;
  margin-bottom: 10px !important;
  display: block !important;
}

.dg-cl {
  display: block !important;
  font-family: 'DM Sans', sans-serif !important;
  font-size: 14px !important;
  font-weight: 400 !important;
  color: #fff !important;
  text-decoration: none !important;
  line-height: 1.9 !important;
  transition: color .2s !important;
}

.dg-cl:hover {
  color: #FD5C62 !important;
}

.dg-addr {
  font-family: 'DM Sans', sans-serif !important;
  font-size: 12px !important;
  color: rgba(255,255,255,.38) !important;
  line-height: 1.8 !important;
}

.dg-socrow {
  display: flex !important;
  flex-wrap: wrap !important;
  gap: 6px !important;
}

.dg-soc {
  display: inline-flex !important;
  font-family: 'DM Sans', sans-serif !important;
  font-size: 10px !important;
  font-weight: 600 !important;
  letter-spacing: .12em !important;
  text-transform: uppercase !important;
  color: rgba(255,255,255,.38) !important;
  text-decoration: none !important;
  border: 1px solid rgba(255,255,255,.1) !important;
  padding: 6px 12px !important;
  border-radius: 100px !important;
  background: transparent !important;
  background-image: none !important;
  transition: color .25s, background-color .25s, border-color .25s !important;
}

.dg-soc:hover {
  color: #fff !important;
  background-color: #FD5C62 !important;
  border-color: #FD5C62 !important;
}

#dgsCtaBtn {
  display: flex !important;
  align-items: center !important;
  justify-content: center !important;
  gap: 10px !important;
  font-family: 'Syne', sans-serif !important;
  font-size: 13px !important;
  font-weight: 700 !important;
  letter-spacing: .1em !important;
  text-transform: uppercase !important;
  color: #fff !important;
  background-color: #FD5C62 !important;
  background-image: none !important;
  padding: 16px 20px !important;
  border-radius: 12px !important;
  text-decoration: none !important;
  border: none !important;
  box-shadow: none !important;
  width: 100% !important;
  transition: transform .3s, box-shadow .3s !important;
}

#dgsCtaBtn:hover {
  transform: translateY(-2px) !important;
  box-shadow: 0 10px 28px rgba(253,92,98,.4) !important;
  color: #fff !important;
}

#dgsCtaBtn svg {
  width: 14px;
  height: 14px;
  stroke: #fff;
  fill: none;
  stroke-width: 2;
  flex-shrink: 0;
}

#dgsFoot {
  flex-shrink: 0 !important;
  border-top: 1px solid var(--bdr) !important;
  padding: 14px 48px !important;
  display: flex !important;
  align-items: center !important;
  justify-content: space-between !important;
  background-color: #080808 !important;
}

#dgsFoot span {
  font-family: 'DM Sans', sans-serif !important;
  font-size: 11px !important;
  color: rgba(255,255,255,.28) !important;
}

.dg-fl {
  display: flex !important;
  gap: 20px !important;
}

.dg-fl a {
  font-family: 'DM Sans', sans-serif !important;
  font-size: 11px !important;
  font-weight: 500 !important;
  letter-spacing: .1em !important;
  text-transform: uppercase !important;
  color: rgba(255,255,255,.28) !important;
  text-decoration: none !important;
  transition: color .2s !important;
}

.dg-fl a:hover {
  color: #fff !important;
}

@media (max-height: 760px) and (min-width: 861px) {
  #dgsPanelBody {
    overflow-y: auto !important;
    -webkit-overflow-scrolling: touch !important;
  }

  #dgsLinks {
    justify-content: flex-start !important;
    overflow: visible !important;
    padding-top: 30px !important;
  }

  .dg-lbl {
    font-size: clamp(24px, 3.1vw, 42px) !important;
  }

  .dg-row {
    padding: 8px 0 !important;
  }

  #dgsInfo {
    padding: 24px !important;
  }
}

@media (max-width: 860px) {
  #dgsNav {
    --bar: 72px;
  }

  #dgsBar {
    padding: 0 16px !important;
    height: 72px !important;
    max-width: 100vw !important;
  }

  #dgsLogo {
    height: 72px !important;
  }

  #dgsLogo img {
    height: 58px !important;
    width: 58px !important;
  }

  #dgsPill {
    display: none !important;
    visibility: hidden !important;
    width: 0 !important;
    height: 0 !important;
    overflow: hidden !important;
    padding: 0 !important;
    margin: 0 !important;
    pointer-events: none !important;
  }

  #dgsTrig {
    padding: 9px 14px !important;
    gap: 8px !important;
  }

  #dgsPanelBody {
    grid-template-columns: 1fr !important;
    overflow-x: hidden !important;
    overflow-y: auto !important;
    -webkit-overflow-scrolling: touch !important;
    max-width: 100vw !important;
    height: 100% !important;
  }

  #dgsLinks {
    padding: 14px 16px 6px !important;
    border-right: none !important;
    border-bottom: 1px solid var(--bdr) !important;
    justify-content: flex-start !important;
    overflow: visible !important;
    max-width: 100vw !important;
    min-width: 0 !important;
  }

  .dg-mq {
    display: none !important;
  }

  .dg-lbl {
    font-size: clamp(24px, 6.2vw, 34px) !important;
  }

  .dg-row {
    padding: 6px 0 !important;
  }

  .dg-sub {
    grid-template-columns: repeat(2,1fr) !important;
    gap: 2px 10px !important;
  }

  .dg-sub.open {
    max-height: 300px !important;
    padding: 2px 0 10px !important;
  }

  .dg-sub a {
    font-size: 12px !important;
    line-height: 1.35 !important;
    padding: 4px 0 !important;
  }

  #dgsSvcItem .dg-badge::after {
    display: none !important;
  }

  #dgsSvcItem .dg-badge {
    padding: 0 10px !important;
    width: auto !important;
    min-width: 36px !important;
  }

  #dgsInfo {
    padding: 12px 16px 14px !important;
    max-width: 100vw !important;
    overflow-x: hidden !important;
  }

  .dg-ib {
    margin-bottom: 10px !important;
  }

  .dg-lbl2 {
    margin-bottom: 5px !important;
    font-size: 9px !important;
  }

  .dg-cl {
    font-size: 12px !important;
    line-height: 1.45 !important;
    word-break: break-word !important;
  }

  .dg-addr {
    font-size: 11px !important;
    line-height: 1.45 !important;
    margin: 0 !important;
  }

  .dg-socrow {
    gap: 5px !important;
    flex-wrap: wrap !important;
    max-width: 100% !important;
  }

  .dg-soc {
    font-size: 9px !important;
    padding: 5px 10px !important;
  }

  #dgsCtaBtn {
    padding: 11px 16px !important;
    font-size: 11px !important;
    letter-spacing: .08em !important;
    width: 100% !important;
    max-width: 100% !important;
    margin-top: 4px !important;
    border-radius: 10px !important;
  }

  #dgsFoot {
    padding: 8px 16px !important;
    flex-direction: column !important;
    gap: 4px !important;
    align-items: flex-start !important;
    max-width: 100vw !important;
    overflow-x: hidden !important;
  }

  #dgsFoot span {
    font-size: 10px !important;
  }

  .dg-fl {
    gap: 12px !important;
  }

  .dg-fl a {
    font-size: 10px !important;
  }
}

@media (max-width: 480px) {
  #dgsTrigLabel {
    display: none !important;
  }

  #dgsTrig {
    padding: 10px 12px !important;
    gap: 0 !important;
  }

  #dgsRight {
    gap: 8px !important;
  }

  .dg-lbl {
    font-size: clamp(23px, 6vw, 32px) !important;
  }

  .dg-sub a {
    font-size: 12px !important;
  }

  #dgsInfo {
    padding-top: 10px !important;
  }
}

@media (max-width: 420px) and (max-height: 740px) {
  .dg-lbl {
    font-size: clamp(21px, 5.6vw, 28px) !important;
  }

  .dg-row {
    padding: 5px 0 !important;
  }

  #dgsLinks {
    padding: 10px 14px 4px !important;
  }

  #dgsInfo {
    padding: 9px 14px 10px !important;
  }

  .dg-ib {
    margin-bottom: 8px !important;
  }

  .dg-cl {
    font-size: 11px !important;
    line-height: 1.35 !important;
  }

  .dg-addr {
    font-size: 10.5px !important;
    line-height: 1.35 !important;
  }

  .dg-soc {
    font-size: 8px !important;
    padding: 4px 8px !important;
  }

  #dgsCtaBtn {
    padding: 9px 14px !important;
  }

  #dgsFoot {
    padding: 6px 14px !important;
  }

  #dgsFoot span,
  .dg-fl a {
    font-size: 9px !important;
  }
}


/* DGS Let's Talk Popup Form - scoped and responsive */
#dgsTalkPopup,
#dgsTalkPopup *,
#dgsTalkPopup *::before,
#dgsTalkPopup *::after {
  box-sizing: border-box !important;
  -webkit-font-smoothing: antialiased !important;
}

#dgsTalkPopup {
  position: fixed !important;
  inset: 0 !important;
  z-index: 1000000 !important;
  display: none !important;
  align-items: center !important;
  justify-content: center !important;
  padding: 22px !important;
  font-family: 'DM Sans', sans-serif !important;
}

#dgsTalkPopup.is-open {
  display: flex !important;
}

.dgs-talk-backdrop {
  position: absolute !important;
  inset: 0 !important;
  background:
    radial-gradient(circle at 22% 18%, rgba(253,92,98,.20), transparent 34%),
    radial-gradient(circle at 80% 78%, rgba(253,92,98,.14), transparent 32%),
    rgba(8,8,8,.84) !important;
  backdrop-filter: blur(18px) !important;
  -webkit-backdrop-filter: blur(18px) !important;
  opacity: 0 !important;
  transition: opacity .28s ease !important;
}

#dgsTalkPopup.is-open .dgs-talk-backdrop {
  opacity: 1 !important;
}

.dgs-talk-box {
  position: relative !important;
  z-index: 2 !important;
  width: min(100%, 540px) !important;
  max-height: 88vh !important;
  overflow-y: auto !important;
  background: rgba(8,8,8,.94) !important;
  border: 1px solid rgba(255,255,255,.12) !important;
  border-radius: 22px !important;
  color: #fff !important;
  box-shadow: 0 34px 100px rgba(0,0,0,.72), 0 0 46px rgba(253,92,98,.16) !important;
  transform: translateY(18px) scale(.97) !important;
  opacity: 0 !important;
  transition: transform .32s cubic-bezier(.76,0,.24,1), opacity .28s ease !important;
}

#dgsTalkPopup.is-open .dgs-talk-box {
  transform: translateY(0) scale(1) !important;
  opacity: 1 !important;
}

.dgs-talk-box::before {
  content: '' !important;
  position: absolute !important;
  left: 0 !important;
  right: 0 !important;
  top: 0 !important;
  height: 3px !important;
  border-radius: 22px 22px 0 0 !important;
  background: linear-gradient(90deg, #FD5C62, #ff8a75, #FD5C62) !important;
}

.dgs-talk-head {
  position: sticky !important;
  top: 0 !important;
  z-index: 3 !important;
  padding: 28px 64px 20px 28px !important;
  background: rgba(8,8,8,.96) !important;
  backdrop-filter: blur(18px) !important;
  -webkit-backdrop-filter: blur(18px) !important;
  border-bottom: 1px solid rgba(255,255,255,.08) !important;
  border-radius: 22px 22px 0 0 !important;
}

.dgs-talk-kicker {
  display: inline-flex !important;
  align-items: center !important;
  gap: 8px !important;
  margin-bottom: 10px !important;
  font-size: 11px !important;
  font-weight: 700 !important;
  letter-spacing: .18em !important;
  text-transform: uppercase !important;
  color: rgba(255,255,255,.55) !important;
}

.dgs-talk-kicker::before {
  content: '' !important;
  width: 7px !important;
  height: 7px !important;
  border-radius: 999px !important;
  background: #FD5C62 !important;
  box-shadow: 0 0 18px rgba(253,92,98,.85) !important;
}

.dgs-talk-title {
  margin: 0 0 8px !important;
  font-family: 'Syne', sans-serif !important;
  font-size: clamp(27px, 4vw, 36px) !important;
  line-height: 1.05 !important;
  font-weight: 800 !important;
  letter-spacing: -.04em !important;
  color: #fff !important;
  text-transform: uppercase !important;
}

.dgs-talk-title span {
  color: #FD5C62 !important;
}

.dgs-talk-subtitle {
  margin: 0 !important;
  font-size: 14.5px !important;
  line-height: 1.65 !important;
  color: rgba(255,255,255,.62) !important;
}

.dgs-talk-close {
  position: absolute !important;
  top: 20px !important;
  right: 20px !important;
  width: 38px !important;
  height: 38px !important;
  border: 1px solid rgba(255,255,255,.14) !important;
  border-radius: 999px !important;
  background: rgba(255,255,255,.06) !important;
  color: #fff !important;
  font-size: 22px !important;
  line-height: 1 !important;
  cursor: pointer !important;
  display: inline-flex !important;
  align-items: center !important;
  justify-content: center !important;
  transition: all .25s ease !important;
}

.dgs-talk-close:hover {
  border-color: #FD5C62 !important;
  background: rgba(253,92,98,.16) !important;
  transform: rotate(90deg) !important;
}

.dgs-talk-body {
  padding: 26px 28px 30px !important;
}

.dgs-talk-form .fluentform,
.dgs-talk-form form {
  text-align: left !important;
}

.dgs-talk-form .ff-el-group {
  margin-bottom: 16px !important;
}

.dgs-talk-form label,
.dgs-talk-form .ff-el-input--label label {
  color: rgba(255,255,255,.82) !important;
  font-size: 13.5px !important;
  font-weight: 500 !important;
  margin-bottom: 7px !important;
}

.dgs-talk-form input,
.dgs-talk-form textarea,
.dgs-talk-form select,
.dgs-talk-form .ff-el-form-control {
  width: 100% !important;
  min-height: 48px !important;
  padding: 13px 15px !important;
  border-radius: 12px !important;
  border: 1px solid rgba(255,255,255,.14) !important;
  background: rgba(255,255,255,.055) !important;
  color: #fff !important;
  box-shadow: none !important;
  outline: none !important;
}

.dgs-talk-form textarea,
.dgs-talk-form textarea.ff-el-form-control {
  min-height: 112px !important;
  resize: vertical !important;
}

.dgs-talk-form input::placeholder,
.dgs-talk-form textarea::placeholder {
  color: rgba(255,255,255,.38) !important;
}

.dgs-talk-form input:focus,
.dgs-talk-form textarea:focus,
.dgs-talk-form select:focus,
.dgs-talk-form .ff-el-form-control:focus {
  border-color: #FD5C62 !important;
  box-shadow: 0 0 0 3px rgba(253,92,98,.15) !important;
}

.dgs-talk-form .ff-btn-submit,
.dgs-talk-form button[type="submit"],
.dgs-talk-form input[type="submit"] {
  width: 100% !important;
  min-height: 52px !important;
  border: 0 !important;
  border-radius: 12px !important;
  background: #FD5C62 !important;
  color: #fff !important;
  font-family: 'Syne', sans-serif !important;
  font-size: 14px !important;
  font-weight: 800 !important;
  letter-spacing: .08em !important;
  text-transform: uppercase !important;
  cursor: pointer !important;
  box-shadow: 0 10px 34px rgba(253,92,98,.32) !important;
  transition: transform .25s ease, box-shadow .25s ease !important;
}

.dgs-talk-form .ff-btn-submit:hover,
.dgs-talk-form button[type="submit"]:hover,
.dgs-talk-form input[type="submit"]:hover {
  transform: translateY(-2px) !important;
  box-shadow: 0 14px 42px rgba(253,92,98,.42) !important;
}

.dgs-talk-form .ff_form_title,
.dgs-talk-form .fluentform .ff-form-title {
  display: none !important;
}

html.dgs-talk-popup-active,
body.dgs-talk-popup-active {
  overflow: hidden !important;
}

@media (max-width: 767px) {
  #dgsTalkPopup {
    align-items: flex-end !important;
    padding: 12px !important;
  }

  .dgs-talk-box {
    width: 100% !important;
    max-height: 92vh !important;
    border-radius: 20px !important;
  }

  .dgs-talk-box::before,
  .dgs-talk-head {
    border-radius: 20px 20px 0 0 !important;
  }

  .dgs-talk-head {
    padding: 24px 58px 18px 20px !important;
  }

  .dgs-talk-body {
    padding: 22px 20px 24px !important;
  }

  .dgs-talk-title {
    font-size: 27px !important;
  }

  .dgs-talk-subtitle {
    font-size: 14px !important;
  }

  .dgs-talk-close {
    top: 18px !important;
    right: 18px !important;
    width: 36px !important;
    height: 36px !important;
  }
}

@media (max-width: 420px) {
  #dgsTalkPopup {
    padding: 8px !important;
  }

  .dgs-talk-head {
    padding: 22px 54px 16px 18px !important;
  }

  .dgs-talk-body {
    padding: 20px 18px 22px !important;
  }
}



/* DGS Popup v2 fixes: no desktop inner scrollbar, no orange top accent, captcha-safe sizing */
#dgsTalkPopup {
  overflow: hidden !important;
}

#dgsTalkPopup .dgs-talk-backdrop {
  background: rgba(0, 0, 0, 0.72) !important;
  backdrop-filter: blur(18px) !important;
  -webkit-backdrop-filter: blur(18px) !important;
}

#dgsTalkPopup .dgs-talk-box {
  width: min(92vw, 640px) !important;
  max-height: none !important;
  overflow: visible !important;
  border-color: rgba(255,255,255,.10) !important;
}

#dgsTalkPopup .dgs-talk-box::before {
  display: none !important;
}

#dgsTalkPopup .dgs-talk-kicker::before {
  background: rgba(255,255,255,.42) !important;
  box-shadow: none !important;
}

#dgsTalkPopup .dgs-talk-close {
  width: 38px !important;
  height: 38px !important;
  min-width: 38px !important;
  max-width: 38px !important;
  min-height: 38px !important;
  max-height: 38px !important;
  padding: 0 !important;
  margin: 0 !important;
  border-radius: 50% !important;
  background: rgba(255,255,255,.06) !important;
  background-image: none !important;
  box-shadow: none !important;
  color: #fff !important;
  appearance: none !important;
  -webkit-appearance: none !important;
}

#dgsTalkPopup .dgs-talk-form .g-recaptcha,
#dgsTalkPopup .dgs-talk-form .ff-el-recaptcha,
#dgsTalkPopup .dgs-talk-form .ff-el-hcaptcha,
#dgsTalkPopup .dgs-talk-form .cf-turnstile {
  position: relative !important;
  z-index: 4 !important;
  max-width: 100% !important;
  overflow: visible !important;
}

#dgsTalkPopup .dgs-talk-form iframe[src*="recaptcha"],
#dgsTalkPopup .dgs-talk-form iframe[src*="google.com/recaptcha"],
#dgsTalkPopup .dgs-talk-form iframe[src*="hcaptcha"],
#dgsTalkPopup .dgs-talk-form iframe[src*="challenges.cloudflare"] {
  max-width: 100% !important;
}

.grecaptcha-badge,
div[style*="z-index: 2000000000"],
iframe[src*="google.com/recaptcha"] {
  z-index: 2147483647 !important;
}

@media (min-width: 768px) {
  #dgsTalkPopup .dgs-talk-head {
    position: relative !important;
    top: auto !important;
  }

  #dgsTalkPopup .dgs-talk-body {
    overflow: visible !important;
  }
}

@media (max-width: 767px) {
  #dgsTalkPopup {
    overflow: hidden !important;
  }

  #dgsTalkPopup .dgs-talk-box {
    width: 100% !important;
    max-height: 92vh !important;
    overflow-y: auto !important;
    overflow-x: hidden !important;
    -webkit-overflow-scrolling: touch !important;
  }

  #dgsTalkPopup .dgs-talk-form iframe[src*="recaptcha"],
  #dgsTalkPopup .dgs-talk-form iframe[src*="google.com/recaptcha"] {
    max-width: 100% !important;
  }
}

@media (max-width: 360px) {
  #dgsTalkPopup .dgs-talk-body {
    padding-left: 14px !important;
    padding-right: 14px !important;
  }

  #dgsTalkPopup .dgs-talk-form .g-recaptcha,
  #dgsTalkPopup .dgs-talk-form .ff-el-recaptcha {
    transform: scale(.92) !important;
    transform-origin: left top !important;
    margin-bottom: -22px !important;
  }
}


/* DGS Popup v3 hard fixes: select dropdown visibility + remove all accent artifacts */
#dgsTalkPopup,
#dgsTalkPopup * {
  scrollbar-width: none !important;
}

@media (min-width: 768px) {
  #dgsTalkPopup,
  #dgsTalkPopup .dgs-talk-box,
  #dgsTalkPopup .dgs-talk-body,
  #dgsTalkPopup .dgs-talk-form,
  #dgsTalkPopup .fluentform,
  #dgsTalkPopup form {
    overflow: visible !important;
  }

  #dgsTalkPopup ::-webkit-scrollbar {
    width: 0 !important;
    height: 0 !important;
    display: none !important;
  }
}

@media (max-width: 767px) {
  #dgsTalkPopup .dgs-talk-box {
    scrollbar-width: thin !important;
  }
}

#dgsTalkPopup .dgs-talk-box,
#dgsTalkPopup .dgs-talk-head {
  border-top-color: rgba(255,255,255,.10) !important;
  box-shadow: 0 34px 100px rgba(0,0,0,.72) !important;
}

#dgsTalkPopup .dgs-talk-box::before,
#dgsTalkPopup .dgs-talk-box::after,
#dgsTalkPopup .dgs-talk-head::before,
#dgsTalkPopup .dgs-talk-head::after {
  content: none !important;
  display: none !important;
  width: 0 !important;
  height: 0 !important;
  background: transparent !important;
  border: 0 !important;
  box-shadow: none !important;
}

#dgsTalkPopup .dgs-talk-kicker::before {
  background: rgba(255,255,255,.45) !important;
  box-shadow: none !important;
}

#dgsTalkPopup .dgs-talk-title span {
  color: #fff !important;
}

#dgsTalkPopup .dgs-talk-form select,
#dgsTalkPopup .dgs-talk-form select.ff-el-form-control {
  color: #ffffff !important;
  background-color: rgba(255,255,255,.055) !important;
  background-image: none !important;
  -webkit-text-fill-color: #ffffff !important;
  appearance: auto !important;
  -webkit-appearance: menulist !important;
}

#dgsTalkPopup .dgs-talk-form select option,
#dgsTalkPopup .dgs-talk-form select optgroup {
  color: #111111 !important;
  background-color: #ffffff !important;
  -webkit-text-fill-color: #111111 !important;
}

#dgsTalkPopup .dgs-talk-form select option:checked,
#dgsTalkPopup .dgs-talk-form select option:hover,
#dgsTalkPopup .dgs-talk-form select option:focus {
  color: #ffffff !important;
  background-color: #FD5C62 !important;
  -webkit-text-fill-color: #ffffff !important;
}

#dgsTalkPopup .dgs-talk-form .ff-el-input--content,
#dgsTalkPopup .dgs-talk-form .ff-el-form-check,
#dgsTalkPopup .dgs-talk-form .ff-el-form-check-label {
  color: rgba(255,255,255,.82) !important;
}

#dgsTalkPopup .dgs-talk-form .ff-el-form-control:disabled,
#dgsTalkPopup .dgs-talk-form .ff-el-form-control[readonly] {
  color: rgba(255,255,255,.70) !important;
  -webkit-text-fill-color: rgba(255,255,255,.70) !important;
}

/* Keep captcha visible without forcing the popup to scroll on desktop */
@media (min-width: 768px) {
  #dgsTalkPopup .dgs-talk-box {
    width: min(92vw, 660px) !important;
  }

  #dgsTalkPopup .dgs-talk-form .g-recaptcha,
  #dgsTalkPopup .dgs-talk-form .ff-el-recaptcha,
  #dgsTalkPopup .dgs-talk-form .cf-turnstile {
    transform: none !important;
    transform-origin: left top !important;
  }
}


/* DGS Popup v4: no page overlay background + hard select/dropdown visibility override */
#dgsTalkPopup {
  background: transparent !important;
  pointer-events: none !important;
  padding: 18px !important;
}

#dgsTalkPopup.is-open {
  pointer-events: auto !important;
}

#dgsTalkPopup .dgs-talk-backdrop {
  background: transparent !important;
  background-color: transparent !important;
  background-image: none !important;
  backdrop-filter: none !important;
  -webkit-backdrop-filter: none !important;
}

#dgsTalkPopup .dgs-talk-box {
  background: rgba(8,8,8,.98) !important;
  box-shadow: 0 32px 90px rgba(0,0,0,.72) !important;
  border-color: rgba(255,255,255,.14) !important;
}

/* Remove remaining red/orange decorative artifacts from popup top area */
#dgsTalkPopup .dgs-talk-kicker::before {
  display: none !important;
  content: none !important;
}

#dgsTalkPopup .dgs-talk-title span {
  color: #ffffff !important;
  -webkit-text-fill-color: #ffffff !important;
}

/* Keep desktop popup clean with no visible inner scrollbar */
@media (min-width: 768px) {
  #dgsTalkPopup .dgs-talk-box {
    width: min(92vw, 620px) !important;
    max-height: calc(100vh - 36px) !important;
    overflow: hidden !important;
  }

  #dgsTalkPopup .dgs-talk-head {
    position: relative !important;
  }

  #dgsTalkPopup .dgs-talk-body {
    max-height: calc(100vh - 250px) !important;
    overflow: visible !important;
  }
}

/* Hard override for theme/plugin dropdown colors */
body #dgsTalkPopup .dgs-talk-form select,
body #dgsTalkPopup .dgs-talk-form select.ff-el-form-control,
body #dgsTalkPopup .dgs-talk-form .ff-el-form-control[type="select"],
body #dgsTalkPopup .dgs-talk-form .ff-el-input--content select,
body #dgsTalkPopup .fluentform select,
body #dgsTalkPopup form select {
  color: #ffffff !important;
  -webkit-text-fill-color: #ffffff !important;
  background: #151515 !important;
  background-color: #151515 !important;
  background-image: none !important;
  border-color: rgba(255,255,255,.18) !important;
  text-shadow: none !important;
  forced-color-adjust: none !important;
  opacity: 1 !important;
}

body #dgsTalkPopup .dgs-talk-form select option,
body #dgsTalkPopup .dgs-talk-form select optgroup,
body #dgsTalkPopup .dgs-talk-form .ff-el-form-control option,
body #dgsTalkPopup .fluentform select option,
body #dgsTalkPopup form select option,
body #dgsTalkPopup option {
  color: #ffffff !important;
  -webkit-text-fill-color: #ffffff !important;
  background: #111111 !important;
  background-color: #111111 !important;
  text-shadow: none !important;
  forced-color-adjust: none !important;
  opacity: 1 !important;
}

body #dgsTalkPopup .dgs-talk-form select option:checked,
body #dgsTalkPopup .dgs-talk-form select option:hover,
body #dgsTalkPopup .dgs-talk-form select option:focus,
body #dgsTalkPopup .dgs-talk-form select option:active,
body #dgsTalkPopup option:checked,
body #dgsTalkPopup option:hover {
  color: #ffffff !important;
  -webkit-text-fill-color: #ffffff !important;
  background: #FD5C62 !important;
  background-color: #FD5C62 !important;
}

/* Fluent Forms can add select2/nice-select wrappers depending on settings */
body #dgsTalkPopup .select2-container,
body #dgsTalkPopup .select2-dropdown,
body #dgsTalkPopup .select2-results,
body #dgsTalkPopup .select2-results__options,
body #dgsTalkPopup .nice-select,
body #dgsTalkPopup .nice-select .list {
  background: #111111 !important;
  color: #ffffff !important;
  border-color: rgba(255,255,255,.18) !important;
  z-index: 2147483647 !important;
}

body #dgsTalkPopup .select2-results__option,
body #dgsTalkPopup .nice-select .option {
  background: #111111 !important;
  color: #ffffff !important;
  -webkit-text-fill-color: #ffffff !important;
}

body #dgsTalkPopup .select2-results__option--highlighted,
body #dgsTalkPopup .select2-results__option[aria-selected="true"],
body #dgsTalkPopup .nice-select .option:hover,
body #dgsTalkPopup .nice-select .option.focus,
body #dgsTalkPopup .nice-select .option.selected {
  background: #FD5C62 !important;
  color: #ffffff !important;
  -webkit-text-fill-color: #ffffff !important;
}

/* Mobile remains scrollable only when needed */
@media (max-width: 767px) {
  #dgsTalkPopup {
    padding: 8px !important;
  }

  #dgsTalkPopup .dgs-talk-box {
    max-height: 92vh !important;
    overflow-y: auto !important;
    overflow-x: hidden !important;
  }

  #dgsTalkPopup .dgs-talk-body {
    max-height: none !important;
  }
}


/* === DGS POPUP HARD OVERRIDES - no overlay background, no desktop internal scrollbar, fixed select dropdown === */
#dgsTalkPopup {
  background: transparent !important;
  pointer-events: none !important;
}

#dgsTalkPopup.is-open {
  pointer-events: auto !important;
}

#dgsTalkPopup .dgs-talk-backdrop {
  background: transparent !important;
  background-image: none !important;
  backdrop-filter: none !important;
  -webkit-backdrop-filter: none !important;
  opacity: 1 !important;
}

#dgsTalkPopup .dgs-talk-box {
  max-height: none !important;
  overflow: visible !important;
  width: min(100%, 560px) !important;
  background: #080808 !important;
}

#dgsTalkPopup .dgs-talk-box::before,
#dgsTalkPopup .dgs-talk-kicker::before {
  content: none !important;
  display: none !important;
  width: 0 !important;
  height: 0 !important;
  background: transparent !important;
  box-shadow: none !important;
}

#dgsTalkPopup .dgs-talk-kicker {
  gap: 0 !important;
}

#dgsTalkPopup .dgs-talk-head {
  position: relative !important;
  top: auto !important;
  background: #080808 !important;
  backdrop-filter: none !important;
  -webkit-backdrop-filter: none !important;
}

#dgsTalkPopup .dgs-talk-form select,
#dgsTalkPopup .dgs-talk-form select.ff-el-form-control,
#dgsTalkPopup .dgs-talk-form .ff-el-form-control[type="select"] {
  color: #ffffff !important;
  background-color: #171717 !important;
  background-image: none !important;
  -webkit-text-fill-color: #ffffff !important;
  appearance: auto !important;
  -webkit-appearance: auto !important;
}

#dgsTalkPopup .dgs-talk-form select option,
#dgsTalkPopup .dgs-talk-form select optgroup,
#dgsTalkPopup .dgs-talk-form .ff-el-form-control option {
  color: #111111 !important;
  background-color: #ffffff !important;
  -webkit-text-fill-color: #111111 !important;
  font-size: 15px !important;
  line-height: 1.5 !important;
}

#dgsTalkPopup .dgs-talk-form select option:checked,
#dgsTalkPopup .dgs-talk-form select option:hover {
  color: #ffffff !important;
  background-color: #FD5C62 !important;
  -webkit-text-fill-color: #ffffff !important;
}

@media (max-width: 767px) {
  #dgsTalkPopup {
    align-items: flex-end !important;
    padding: 8px !important;
  }

  #dgsTalkPopup .dgs-talk-box {
    width: 100% !important;
    max-height: 92dvh !important;
    overflow-y: auto !important;
    -webkit-overflow-scrolling: touch !important;
  }

  #dgsTalkPopup .dgs-talk-head {
    position: sticky !important;
    top: 0 !important;
  }
}


/* === DGS FINAL POPUP SCROLL FIX ===
   Shows the full Fluent Form inside the popup with a branded gradient scrollbar.
   Keeps the page behind the popup untouched: no dark overlay, no blur background. */
#dgsTalkPopup {
  background: transparent !important;
  background-image: none !important;
  backdrop-filter: none !important;
  -webkit-backdrop-filter: none !important;
  overflow: hidden !important;
  pointer-events: none !important;
  padding: 16px !important;
  align-items: flex-start !important;
  justify-content: center !important;
}

#dgsTalkPopup.is-open {
  pointer-events: auto !important;
}

#dgsTalkPopup .dgs-talk-backdrop {
  background: transparent !important;
  background-color: transparent !important;
  background-image: none !important;
  backdrop-filter: none !important;
  -webkit-backdrop-filter: none !important;
  opacity: 1 !important;
}

#dgsTalkPopup .dgs-talk-box {
  width: min(92vw, 640px) !important;
  max-height: calc(100dvh - 32px) !important;
  overflow-y: auto !important;
  overflow-x: hidden !important;
  background: #080808 !important;
  border: 1px solid rgba(255,255,255,.14) !important;
  border-radius: 22px !important;
  box-shadow: 0 32px 90px rgba(0,0,0,.72) !important;
  scrollbar-width: thin !important;
  scrollbar-color: #FD5C62 rgba(255,255,255,.08) !important;
  -webkit-overflow-scrolling: touch !important;
}

#dgsTalkPopup .dgs-talk-box::-webkit-scrollbar {
  width: 10px !important;
}

#dgsTalkPopup .dgs-talk-box::-webkit-scrollbar-track {
  background: rgba(255,255,255,.07) !important;
  border-radius: 999px !important;
  margin: 16px 0 !important;
}

#dgsTalkPopup .dgs-talk-box::-webkit-scrollbar-thumb {
  background: linear-gradient(180deg, #FD5C62 0%, #E91E8C 52%, #FF6B35 100%) !important;
  border-radius: 999px !important;
  border: 2px solid #080808 !important;
}

#dgsTalkPopup .dgs-talk-box::-webkit-scrollbar-thumb:hover {
  background: linear-gradient(180deg, #FF6B35 0%, #E91E8C 52%, #FD5C62 100%) !important;
}

#dgsTalkPopup .dgs-talk-head {
  position: sticky !important;
  top: 0 !important;
  z-index: 5 !important;
  background: #080808 !important;
  backdrop-filter: none !important;
  -webkit-backdrop-filter: none !important;
}

#dgsTalkPopup .dgs-talk-body {
  max-height: none !important;
  overflow: visible !important;
}

#dgsTalkPopup .dgs-talk-box::before,
#dgsTalkPopup .dgs-talk-box::after,
#dgsTalkPopup .dgs-talk-head::before,
#dgsTalkPopup .dgs-talk-head::after,
#dgsTalkPopup .dgs-talk-kicker::before {
  content: none !important;
  display: none !important;
  background: transparent !important;
  box-shadow: none !important;
  border: 0 !important;
}

#dgsTalkPopup .dgs-talk-kicker {
  gap: 0 !important;
}

/* Theme/plugin select dropdown visibility override */
body #dgsTalkPopup .dgs-talk-form select,
body #dgsTalkPopup .dgs-talk-form select.ff-el-form-control,
body #dgsTalkPopup .dgs-talk-form .ff-el-input--content select,
body #dgsTalkPopup .fluentform select,
body #dgsTalkPopup form select {
  color: #ffffff !important;
  -webkit-text-fill-color: #ffffff !important;
  background: #171717 !important;
  background-color: #171717 !important;
  background-image: none !important;
  border-color: rgba(255,255,255,.18) !important;
  opacity: 1 !important;
  appearance: auto !important;
  -webkit-appearance: auto !important;
}

body #dgsTalkPopup .dgs-talk-form select option,
body #dgsTalkPopup .dgs-talk-form select optgroup,
body #dgsTalkPopup .dgs-talk-form .ff-el-form-control option,
body #dgsTalkPopup .fluentform select option,
body #dgsTalkPopup form select option,
body #dgsTalkPopup option {
  color: #111111 !important;
  -webkit-text-fill-color: #111111 !important;
  background: #ffffff !important;
  background-color: #ffffff !important;
  opacity: 1 !important;
}

body #dgsTalkPopup .dgs-talk-form select option:checked,
body #dgsTalkPopup .dgs-talk-form select option:hover,
body #dgsTalkPopup option:checked,
body #dgsTalkPopup option:hover {
  color: #ffffff !important;
  -webkit-text-fill-color: #ffffff !important;
  background: #FD5C62 !important;
  background-color: #FD5C62 !important;
}

/* ReCAPTCHA / Turnstile stays visible inside the scrollable popup */
#dgsTalkPopup .dgs-talk-form .g-recaptcha,
#dgsTalkPopup .dgs-talk-form .ff-el-recaptcha,
#dgsTalkPopup .dgs-talk-form .ff-el-hcaptcha,
#dgsTalkPopup .dgs-talk-form .cf-turnstile,
#dgsTalkPopup .dgs-talk-form iframe[src*="recaptcha"],
#dgsTalkPopup .dgs-talk-form iframe[src*="hcaptcha"],
#dgsTalkPopup .dgs-talk-form iframe[src*="challenges.cloudflare"] {
  max-width: 100% !important;
  position: relative !important;
  z-index: 6 !important;
}

@media (max-width: 767px) {
  #dgsTalkPopup {
    align-items: flex-end !important;
    padding: 8px !important;
  }

  #dgsTalkPopup .dgs-talk-box {
    width: 100% !important;
    max-height: 92dvh !important;
    border-radius: 20px !important;
  }

  #dgsTalkPopup .dgs-talk-box::-webkit-scrollbar {
    width: 7px !important;
  }
}`}}),(0,b.jsx)("div",{dangerouslySetInnerHTML:{__html:`<div id="dgsNav"><nav id="dgsBar">
<a href="https://www.dgeniussolutions.com/" id="dgsLogo">
<img width="117" height="117" src="https://www.dgeniussolutions.com/wp-content/uploads/2025/11/DGS-LOGO-3.webp" alt="D'Genius Solutions" loading="eager">
</a><div id="dgsRight">
<a href="#" id="dgsPill" class="dgs-talk-trigger">
<svg viewBox="0 0 14 14"><path d="M1 13L13 1M13 1H5M13 1v8" stroke-linecap="round" stroke-linejoin="round"/></svg>
Let's Talk
</a><div id="dgsTrig"
onclick="dgsToggle()"
role="button"
tabindex="0"
onkeydown="if(event.key==='Enter'||event.key===' ')dgsToggle()"
style="background:transparent;background-color:transparent;background-image:none;border:1px solid rgba(255,255,255,0.22);border-radius:100px;padding:10px 18px;cursor:pointer;display:flex;align-items:center;gap:10px;box-shadow:none;outline:none;"><div id="dgsLines">
<em></em><em></em><em></em></div>
<span id="dgsTrigLabel">MENU</span></div></div></nav><div id="dgsOverlay"><div id="dgsPanel"><div id="dgsPanelBody"><div id="dgsLinks"><div class="dg-item">
<a href="https://www.dgeniussolutions.com/" class="dg-row dg-nl">
<span class="dg-lbl">Home</span><div class="dg-badge"><svg viewBox="0 0 14 14" fill="none"><path d="M1 13L13 1M13 1H5M13 1v8" stroke-linecap="round" stroke-linejoin="round"/></svg></div>
</a><div class="dg-mq"><div class="dg-mq-t"><span>AI Marketing Agency •&nbsp;</span><span>Digital Excellence •&nbsp;</span><span>Mumbai Based •&nbsp;</span><span>Founded 2021 •&nbsp;</span><span>AI Marketing Agency •&nbsp;</span><span>Digital Excellence •&nbsp;</span><span>Mumbai Based •&nbsp;</span><span>Founded 2021 •&nbsp;</span></div></div></div><div class="dg-item">
<a href="https://www.dgeniussolutions.com/about-us/" class="dg-row dg-nl">
<span class="dg-lbl">About Us</span><div class="dg-badge"><svg viewBox="0 0 14 14" fill="none"><path d="M1 13L13 1M13 1H5M13 1v8" stroke-linecap="round" stroke-linejoin="round"/></svg></div>
</a><div class="dg-mq"><div class="dg-mq-t"><span>Sneha & Kohin Bellara •&nbsp;</span><span>Tribe of Creators •&nbsp;</span><span>Strategists •&nbsp;</span><span>Tech Enthusiasts •&nbsp;</span><span>Sneha & Kohin Bellara •&nbsp;</span><span>Tribe of Creators •&nbsp;</span><span>Strategists •&nbsp;</span><span>Tech Enthusiasts •&nbsp;</span></div></div></div><div class="dg-item" id="dgsSvcItem"><div class="dg-row" onclick="dgsSvc()" role="button" tabindex="0" onkeydown="if(event.key==='Enter')dgsSvc()" style="cursor:pointer;background:none;border:none;width:100%;outline:none;">
<span class="dg-lbl">Our Services</span><div class="dg-badge"><svg viewBox="0 0 14 14" fill="none"><path d="M2 4l5 5 5-5" stroke-linecap="round" stroke-linejoin="round"/></svg></div></div><div class="dg-mq"><div class="dg-mq-t"><span>AI Video Production •&nbsp;</span><span>SEO •&nbsp;</span><span>AEO •&nbsp;</span><span>GEO •&nbsp;</span><span>LLM SEO •&nbsp;</span><span>Social Media •&nbsp;</span><span>Performance Marketing •&nbsp;</span><span>Web Dev •&nbsp;</span><span>Branding •&nbsp;</span><span>Content •&nbsp;</span><span>AI Video Production •&nbsp;</span><span>SEO •&nbsp;</span><span>AEO •&nbsp;</span><span>GEO •&nbsp;</span><span>LLM SEO •&nbsp;</span><span>Social Media •&nbsp;</span><span>Performance Marketing •&nbsp;</span><span>Web Dev •&nbsp;</span><span>Branding •&nbsp;</span><span>Content •&nbsp;</span></div></div><div class="dg-sub" id="dgsSub">
<a href="https://www.dgeniussolutions.com/services/ai-video-production-agency/" class="dg-nl">AI Video Production</a>
<a href="https://www.dgeniussolutions.com/services/seo-services-in-mumbai/" class="dg-nl">SEO</a>
<a href="https://www.dgeniussolutions.com/services/aeo-services-in-mumbai/" class="dg-nl">AEO</a>
<a href="https://www.dgeniussolutions.com/services/geo/" class="dg-nl">GEO</a>
<a href="https://www.dgeniussolutions.com/services/llm-seo-service/" class="dg-nl">LLM SEO</a>
<a href="https://www.dgeniussolutions.com/services/social-media-marketing/" class="dg-nl">Social Media</a>
<a href="https://www.dgeniussolutions.com/services/performance-marketing/" class="dg-nl">Performance Marketing</a>
<a href="https://www.dgeniussolutions.com/services/website-development-amc/" class="dg-nl">Website Dev</a>
<a href="https://www.dgeniussolutions.com/services/branding/" class="dg-nl">Branding</a>
<a href="https://www.dgeniussolutions.com/services/content-creation/" class="dg-nl">Content Creation</a></div></div><div class="dg-item">
<a href="https://www.dgeniussolutions.com/portfolio/" class="dg-row dg-nl">
<span class="dg-lbl">Portfolio</span><div class="dg-badge"><svg viewBox="0 0 14 14" fill="none"><path d="M1 13L13 1M13 1H5M13 1v8" stroke-linecap="round" stroke-linejoin="round"/></svg></div>
</a><div class="dg-mq"><div class="dg-mq-t"><span>200+ Brands •&nbsp;</span><span>Our Best Work •&nbsp;</span><span>Case Studies •&nbsp;</span><span>Proven Results •&nbsp;</span><span>200+ Brands •&nbsp;</span><span>Our Best Work •&nbsp;</span><span>Case Studies •&nbsp;</span><span>Proven Results •&nbsp;</span></div></div></div><div class="dg-item">
<a href="https://www.dgeniussolutions.com/case_studies/" class="dg-row dg-nl">
<span class="dg-lbl">Case Studies</span><div class="dg-badge"><svg viewBox="0 0 14 14" fill="none"><path d="M1 13L13 1M13 1H5M13 1v8" stroke-linecap="round" stroke-linejoin="round"/></svg></div>
</a><div class="dg-mq"><div class="dg-mq-t"><span>Real Results •&nbsp;</span><span>Client Success Stories •&nbsp;</span><span>SEO • AEO • GEO •&nbsp;</span><span>AI Video Production •&nbsp;</span><span>Website Development •&nbsp;</span><span>Real Results •&nbsp;</span><span>Client Success Stories •&nbsp;</span><span>SEO • AEO • GEO •&nbsp;</span><span>AI Video Production •&nbsp;</span><span>Website Development •&nbsp;</span></div></div></div><div class="dg-item">
<a href="https://www.dgeniussolutions.com/blogs/" class="dg-row dg-nl">
<span class="dg-lbl">Blogs</span><div class="dg-badge"><svg viewBox="0 0 14 14" fill="none"><path d="M1 13L13 1M13 1H5M13 1v8" stroke-linecap="round" stroke-linejoin="round"/></svg></div>
</a><div class="dg-mq"><div class="dg-mq-t"><span>Insights •&nbsp;</span><span>AI Strategy •&nbsp;</span><span>SEO Tips •&nbsp;</span><span>Marketing Ideas •&nbsp;</span><span>Insights •&nbsp;</span><span>AI Strategy •&nbsp;</span><span>SEO Tips •&nbsp;</span><span>Marketing Ideas •&nbsp;</span></div></div></div><div class="dg-item">
<a href="https://www.dgeniussolutions.com/career/" class="dg-row dg-nl">
<span class="dg-lbl">Careers</span><div class="dg-badge"><svg viewBox="0 0 14 14" fill="none"><path d="M1 13L13 1M13 1H5M13 1v8" stroke-linecap="round" stroke-linejoin="round"/></svg></div>
</a><div class="dg-mq"><div class="dg-mq-t"><span>Join The Tribe •&nbsp;</span><span>We're Hiring •&nbsp;</span><span>Creative Minds •&nbsp;</span><span>Grow With Us •&nbsp;</span><span>Join The Tribe •&nbsp;</span><span>We're Hiring •&nbsp;</span><span>Creative Minds •&nbsp;</span><span>Grow With Us •&nbsp;</span></div></div></div><div class="dg-item">
<a href="https://www.dgeniussolutions.com/contact-us/" class="dg-row dg-nl">
<span class="dg-lbl">Contact Us</span><div class="dg-badge"><svg viewBox="0 0 14 14" fill="none"><path d="M1 13L13 1M13 1H5M13 1v8" stroke-linecap="round" stroke-linejoin="round"/></svg></div>
</a><div class="dg-mq"><div class="dg-mq-t"><span>Let's Build Together •&nbsp;</span><span>Every Project Starts With A Conversation •&nbsp;</span><span>Let's Build Together •&nbsp;</span><span>Every Project Starts With A Conversation •&nbsp;</span></div></div></div></div><div id="dgsInfo"><div><div class="dg-ib">
<span class="dg-lbl2">Reach Us</span>
<a href="tel:+919987922901" class="dg-cl">+91 99879 22901</a>
<a href="tel:+918591950238" class="dg-cl">+91 85919 50238</a>
<a href="mailto:business@dgeniussolutions.com" class="dg-cl">business@dgeniussolutions.com</a></div><div class="dg-ib">
<span class="dg-lbl2">The Digital Lab</span><p class="dg-addr">Unit 202, Amore Edge,<br>Swami Vivekanand Rd,<br>Khar West, Mumbai 400052</p></div><div class="dg-ib">
<span class="dg-lbl2">Follow Us</span><div class="dg-socrow">
<a href="https://www.linkedin.com/company/d-genius-solutions/" class="dg-soc" target="_blank" rel="noopener">LinkedIn</a>
<a href="https://www.instagram.com/dgeniussolutions/" class="dg-soc" target="_blank" rel="noopener">Instagram</a>
<a href="https://www.facebook.com/DGeniussolutions/" class="dg-soc" target="_blank" rel="noopener">Facebook</a>
<a href="https://www.youtube.com/@dgeniussolutionspvtltd4060" class="dg-soc" target="_blank" rel="noopener">YouTube</a>
<a href="https://in.pinterest.com/dgeniussolutions/" class="dg-soc" target="_blank" rel="noopener">Pinterest</a></div></div></div><a href="#" id="dgsCtaBtn" class="dgs-talk-trigger">
<svg viewBox="0 0 14 14" fill="none"><path d="M7 1v12M1 7h12" stroke-linecap="round" stroke-linejoin="round"/></svg>
Start a Project
</a></div></div><div id="dgsFoot">
<span>\xa9 2026 D'Genius Solutions. All Rights Reserved.</span><div class="dg-fl">
<a href="https://www.dgeniussolutions.com/privacy-policy/">Privacy Policy</a>
<a href="https://www.dgeniussolutions.com/sitemap/">Sitemap</a></div></div></div></div></div><div id="dgsTalkPopup" aria-hidden="true"><div class="dgs-talk-backdrop" data-dgs-talk-close></div><div class="dgs-talk-box" role="dialog" aria-modal="true" aria-labelledby="dgsTalkTitle"><div class="dgs-talk-head">
<button class="dgs-talk-close" type="button" aria-label="Close popup" data-dgs-talk-close>\xd7</button><div class="dgs-talk-kicker">Start a Conversation</div><div class="dgs-talk-title" id="dgsTalkTitle">Let's Talk <span>Growth</span></div><p class="dgs-talk-subtitle">Tell us what you want to build, improve, or scale. Our team will get back with the next best step.</p></div><div class="dgs-talk-body"><div class="dgs-talk-form"><div class='fluentform ff-default fluentform_wrapper_1 ffs_default_wrap'><form data-form_id="1" id="fluentform_1" class="frm-fluent-form fluent_form_1 ff-el-form-top ff_form_instance_1_1 ff-form-loading ffs_default" data-form_instance="ff_form_instance_1_1" method="POST" ><fieldset  style="border: none!important;margin: 0!important;padding: 0!important;background-color: transparent!important;box-shadow: none!important;outline: none!important; min-inline-size: 100%;"><legend class="ff_screen_reader_title" style="display: block; margin: 0!important;padding: 0!important;height: 0!important;text-indent: -999999px;width: 0!important;overflow:hidden;">Home Page Form</legend><input type='hidden' name='__fluent_form_embded_post_id' value='63505' /><input type="hidden" id="_fluentform_1_fluentformnonce" name="_fluentform_1_fluentformnonce" value="dfa1cac356" /><input type="hidden" name="_wp_http_referer" value="/?utm_source=openai" /><div data-type="name-element" data-name="names" class=" ff-field_container ff-name-field-wrapper" ><div class='ff-t-container'><div class='ff-t-cell '><div class='ff-el-group ff-el-form-top'><div class="ff-el-input--label ff-el-is-required asterisk-right"><label for='ff_1_names_first_name_' id='label_ff_1_names_first_name_' >Full Name</label></div><div class='ff-el-input--content'><input type="text" name="names[first_name]" id="ff_1_names_first_name_" class="ff-el-form-control" placeholder="Enter Your First Name" aria-invalid="false" aria-required=true></div></div></div></div></div><div class='ff-el-group'><div class="ff-el-input--label ff-el-is-required asterisk-right"><label for='ff_1_email' id='label_ff_1_email' aria-label="Email">Email</label></div><div class='ff-el-input--content'><input type="email" name="email" id="ff_1_email" class="ff-el-form-control" placeholder="Email Address" data-name="email"  aria-invalid="false" aria-required=true></div></div><div class='ff-el-group'><div class="ff-el-input--label ff-el-is-required asterisk-right"><label for='ff_1_phone' id='label_ff_1_phone' aria-label="Phone/Mobile">Phone/Mobile</label></div><div class='ff-el-input--content'><input name="phone" class="ff-el-form-control ff-el-phone" type="tel" placeholder="Mobile Number" data-name="phone" id="ff_1_phone" inputmode="tel"  aria-invalid='false' aria-required=true></div></div><div class='ff-el-group'><div class="ff-el-input--label ff-el-is-required asterisk-right"><label for='ff_1_input_text' id='label_ff_1_input_text' aria-label="Company Name">Company Name</label></div><div class='ff-el-input--content'><input type="text" name="input_text" class="ff-el-form-control" data-name="input_text" id="ff_1_input_text"  aria-invalid="false" aria-required=true></div></div><div class='ff-el-group'><div class="ff-el-input--label ff-el-is-required asterisk-right"><label for='ff_1_dropdown_1' id='label_ff_1_dropdown_1' aria-label="How did you hear about us ?">How did you hear about us ?</label></div><div class='ff-el-input--content'><select name="dropdown_1" id="ff_1_dropdown_1" class="ff-el-form-control" data-name="dropdown_1" data-calc_value="0"  aria-invalid="false" aria-required="true" aria-labelledby="label_ff_1_dropdown_1"><option value="">- Select -</option><option value="Google Ads"  >Google Ads</option><option value="Google Search"  >Google Search</option><option value="Friend / Colleague"  >Friend / Colleague</option><option value="Twitter"  >Twitter</option><option value="Youtube"  >Youtube</option><option value="Instagram"  >Instagram</option><option value="Facebook"  >Facebook</option><option value="LinkedIn"  >LinkedIn</option><option value="Podcast"  >Podcast</option><option value="Blog / Article"  >Blog / Article</option><option value="Other"  >Other</option></select></div></div><div class='ff-el-group'><div class="ff-el-input--label ff-el-is-required asterisk-right"><label for='ff_1_subject' id='label_ff_1_subject' aria-label="Subject">Subject</label></div><div class='ff-el-input--content'><input type="text" name="subject" class="ff-el-form-control" placeholder="Subject" data-name="subject" id="ff_1_subject"  aria-invalid="false" aria-required=true></div></div><div class='ff-el-group'><div class="ff-el-input--label ff-el-is-required asterisk-right"><label for='ff_1_dropdown' id='label_ff_1_dropdown' aria-label="Service">Service</label></div><div class='ff-el-input--content'><select name="dropdown" id="ff_1_dropdown" class="ff-el-form-control" data-name="dropdown" data-calc_value="0"  aria-invalid="false" aria-required="true" aria-labelledby="label_ff_1_dropdown"><option value="">- Select -</option><option value="Generative AI"  >Generative AI</option><option value="GEO"  >GEO</option><option value="Search Engine Optimization"  >Search Engine Optimization</option><option value="AEO "  >AEO</option><option value="Social Media Marketing"  >Social Media Marketing</option><option value="Website Design &amp; Development"  >Website Design & Development</option><option value="Content Writing"  >Content Writing</option><option value="Blog Writing"  >Blog Writing</option><option value="Graphic Designing"  >Graphic Designing</option><option value="Influencer Marketing"  >Influencer Marketing</option><option value="Branding"  >Branding</option><option value="Employer Branding"  >Employer Branding</option><option value="LinkedIn Marketing"  >LinkedIn Marketing</option><option value="Video Production"  >Video Production</option><option value="LLM"  >LLM</option></select></div></div><div class='ff-el-group'><div class="ff-el-input--label asterisk-right"><label for='ff_1_message' id='label_ff_1_message' aria-label="Your Message">Your Message</label></div><div class='ff-el-input--content'><textarea aria-required="false" aria-labelledby="label_ff_1_message" name="message" id="ff_1_message" class="ff-el-form-control" placeholder="Your Message" rows="4" cols="2" data-name="message" ></textarea></div></div><input type="hidden" name="Home_Page" data-name="Home_Page" ><div class='ff-el-group ' ><div class='ff-el-input--content'><div data-fluent_id='1' name='g-recaptcha-response'><div
data-sitekey='6LfK6VgsAAAAAFeLVFPu7qFDLc4phIeAPApUFy-k'
id='fluentform-recaptcha-1-1'
class='ff-el-recaptcha g-recaptcha'
data-callback='fluentFormrecaptchaSuccessCallback'></div></div></div></div><input type="hidden" name="Home_Page_form" data-name="Home_Page_form" ><div class='ff-el-group ff-text-left ff_submit_btn_wrapper'><button type="submit" class="ff-btn ff-btn-submit ff-btn-md ff_btn_style"  aria-label="Submit Form">Submit Form</button></div></fieldset></form><div id='fluentform_1_errors' class='ff-errors-in-stack ff_form_instance_1_1 ff-form-loading_errors ff_form_instance_1_1_errors'></div></div> <script type="text/javascript" src="data:text/javascript;base64,d2luZG93LmZsdWVudF9mb3JtX2ZmX2Zvcm1faW5zdGFuY2VfMV8xPXsiaWQiOiIxIiwiYWpheFVybCI6Imh0dHBzOlwvXC93d3cuZGdlbml1c3NvbHV0aW9ucy5jb21cL3dwLWFkbWluXC9hZG1pbi1hamF4LnBocCIsInNldHRpbmdzIjp7ImxheW91dCI6eyJsYWJlbFBsYWNlbWVudCI6InRvcCIsImhlbHBNZXNzYWdlUGxhY2VtZW50Ijoid2l0aF9sYWJlbCIsImVycm9yTWVzc2FnZVBsYWNlbWVudCI6ImlubGluZSIsImNzc0NsYXNzTmFtZSI6IiIsImFzdGVyaXNrUGxhY2VtZW50IjoiYXN0ZXJpc2stcmlnaHQifSwicmVzdHJpY3Rpb25zIjp7ImRlbnlFbXB0eVN1Ym1pc3Npb24iOnsiZW5hYmxlZCI6ITF9fX0sImZvcm1faW5zdGFuY2UiOiJmZl9mb3JtX2luc3RhbmNlXzFfMSIsImZvcm1faWRfc2VsZWN0b3IiOiJmbHVlbnRmb3JtXzEiLCJydWxlcyI6eyJuYW1lc1tmaXJzdF9uYW1lXSI6eyJyZXF1aXJlZCI6eyJ2YWx1ZSI6ITAsIm1lc3NhZ2UiOiJUaGlzIGZpZWxkIGlzIHJlcXVpcmVkIiwiZ2xvYmFsX21lc3NhZ2UiOiJUaGlzIGZpZWxkIGlzIHJlcXVpcmVkIiwiZ2xvYmFsIjohMH19LCJuYW1lc1ttaWRkbGVfbmFtZV0iOnsicmVxdWlyZWQiOnsidmFsdWUiOiExLCJtZXNzYWdlIjoiVGhpcyBmaWVsZCBpcyByZXF1aXJlZCIsImdsb2JhbF9tZXNzYWdlIjoiVGhpcyBmaWVsZCBpcyByZXF1aXJlZCIsImdsb2JhbCI6ITB9fSwibmFtZXNbbGFzdF9uYW1lXSI6eyJyZXF1aXJlZCI6eyJ2YWx1ZSI6ITEsIm1lc3NhZ2UiOiJUaGlzIGZpZWxkIGlzIHJlcXVpcmVkIiwiZ2xvYmFsX21lc3NhZ2UiOiJUaGlzIGZpZWxkIGlzIHJlcXVpcmVkIiwiZ2xvYmFsIjohMH19LCJlbWFpbCI6eyJyZXF1aXJlZCI6eyJ2YWx1ZSI6ITAsIm1lc3NhZ2UiOiJUaGlzIGZpZWxkIGlzIHJlcXVpcmVkIiwiZ2xvYmFsIjohMSwiZ2xvYmFsX21lc3NhZ2UiOiJUaGlzIGZpZWxkIGlzIHJlcXVpcmVkIn0sImVtYWlsIjp7InZhbHVlIjohMCwibWVzc2FnZSI6IlRoaXMgZmllbGQgbXVzdCBjb250YWluIGEgdmFsaWQgZW1haWwiLCJnbG9iYWwiOiExLCJnbG9iYWxfbWVzc2FnZSI6IlRoaXMgZmllbGQgbXVzdCBjb250YWluIGEgdmFsaWQgZW1haWwifX0sInBob25lIjp7InJlcXVpcmVkIjp7InZhbHVlIjohMCwiZ2xvYmFsIjohMCwibWVzc2FnZSI6IlRoaXMgZmllbGQgaXMgcmVxdWlyZWQiLCJnbG9iYWxfbWVzc2FnZSI6IlRoaXMgZmllbGQgaXMgcmVxdWlyZWQifSwidmFsaWRfcGhvbmVfbnVtYmVyIjp7InZhbHVlIjohMSwiZ2xvYmFsIjohMCwibWVzc2FnZSI6IlBob25lIG51bWJlciBpcyBub3QgdmFsaWQiLCJnbG9iYWxfbWVzc2FnZSI6IlBob25lIG51bWJlciBpcyBub3QgdmFsaWQifX0sImlucHV0X3RleHQiOnsicmVxdWlyZWQiOnsidmFsdWUiOiEwLCJtZXNzYWdlIjoiVGhpcyBmaWVsZCBpcyByZXF1aXJlZCIsImdsb2JhbF9tZXNzYWdlIjoiVGhpcyBmaWVsZCBpcyByZXF1aXJlZCIsImdsb2JhbCI6ITB9fSwiZHJvcGRvd25fMSI6eyJyZXF1aXJlZCI6eyJ2YWx1ZSI6ITAsIm1lc3NhZ2UiOiJUaGlzIGZpZWxkIGlzIHJlcXVpcmVkIiwiZ2xvYmFsX21lc3NhZ2UiOiJUaGlzIGZpZWxkIGlzIHJlcXVpcmVkIiwiZ2xvYmFsIjohMH19LCJzdWJqZWN0Ijp7InJlcXVpcmVkIjp7InZhbHVlIjohMCwibWVzc2FnZSI6IlRoaXMgZmllbGQgaXMgcmVxdWlyZWQiLCJnbG9iYWwiOiExLCJnbG9iYWxfbWVzc2FnZSI6IlRoaXMgZmllbGQgaXMgcmVxdWlyZWQifX0sImRyb3Bkb3duIjp7InJlcXVpcmVkIjp7InZhbHVlIjohMCwibWVzc2FnZSI6IlRoaXMgZmllbGQgaXMgcmVxdWlyZWQiLCJnbG9iYWxfbWVzc2FnZSI6IlRoaXMgZmllbGQgaXMgcmVxdWlyZWQiLCJnbG9iYWwiOiEwfX0sIm1lc3NhZ2UiOnsicmVxdWlyZWQiOnsidmFsdWUiOiExLCJtZXNzYWdlIjoiVGhpcyBmaWVsZCBpcyByZXF1aXJlZCIsImdsb2JhbCI6ITEsImdsb2JhbF9tZXNzYWdlIjoiVGhpcyBmaWVsZCBpcyByZXF1aXJlZCJ9fSwiZy1yZWNhcHRjaGEtcmVzcG9uc2UiOltdfSwiZGVib3VuY2VfdGltZSI6MzAwLCJmaWxlX3VwbG9hZF9zZXR0aW5ncyI6W119" defer></script> </div></div></div></div> <script src="data:text/javascript;base64,d2luZG93LmRnc1Njcm9sbFk9MDt3aW5kb3cuZGdzTG9ja1Njcm9sbD1mdW5jdGlvbigpe3dpbmRvdy5kZ3NTY3JvbGxZPXdpbmRvdy5zY3JvbGxZfHxkb2N1bWVudC5kb2N1bWVudEVsZW1lbnQuc2Nyb2xsVG9wfHwwO2RvY3VtZW50LmRvY3VtZW50RWxlbWVudC5zdHlsZS5vdmVyZmxvdz0naGlkZGVuJztkb2N1bWVudC5ib2R5LnN0eWxlLm92ZXJmbG93PSdoaWRkZW4nO2RvY3VtZW50LmJvZHkuc3R5bGUucG9zaXRpb249J2ZpeGVkJztkb2N1bWVudC5ib2R5LnN0eWxlLnRvcD0nLScrd2luZG93LmRnc1Njcm9sbFkrJ3B4Jztkb2N1bWVudC5ib2R5LnN0eWxlLmxlZnQ9JzAnO2RvY3VtZW50LmJvZHkuc3R5bGUucmlnaHQ9JzAnO2RvY3VtZW50LmJvZHkuc3R5bGUud2lkdGg9JzEwMCUnfTt3aW5kb3cuZGdzVW5sb2NrU2Nyb2xsPWZ1bmN0aW9uKCl7dmFyIHk9d2luZG93LmRnc1Njcm9sbFl8fDA7ZG9jdW1lbnQuZG9jdW1lbnRFbGVtZW50LnN0eWxlLm92ZXJmbG93PScnO2RvY3VtZW50LmJvZHkuc3R5bGUub3ZlcmZsb3c9Jyc7ZG9jdW1lbnQuYm9keS5zdHlsZS5wb3NpdGlvbj0nJztkb2N1bWVudC5ib2R5LnN0eWxlLnRvcD0nJztkb2N1bWVudC5ib2R5LnN0eWxlLmxlZnQ9Jyc7ZG9jdW1lbnQuYm9keS5zdHlsZS5yaWdodD0nJztkb2N1bWVudC5ib2R5LnN0eWxlLndpZHRoPScnO3dpbmRvdy5zY3JvbGxUbygwLHkpfTt3aW5kb3cuZGdzVG9nZ2xlPWZ1bmN0aW9uKCl7dmFyIG5hdj1kb2N1bWVudC5nZXRFbGVtZW50QnlJZCgnZGdzTmF2Jyk7dmFyIGxhYmVsPWRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCdkZ3NUcmlnTGFiZWwnKTtpZighbmF2KXJldHVybjt2YXIgb3BlbmluZz0hbmF2LmNsYXNzTGlzdC5jb250YWlucygnbmF2LW9wZW4nKTtuYXYuY2xhc3NMaXN0LnRvZ2dsZSgnbmF2LW9wZW4nLG9wZW5pbmcpO2lmKG9wZW5pbmcpe3dpbmRvdy5kZ3NMb2NrU2Nyb2xsKCl9ZWxzZXt3aW5kb3cuZGdzVW5sb2NrU2Nyb2xsKCl9CmlmKGxhYmVsKWxhYmVsLnRleHRDb250ZW50PW9wZW5pbmc/J0NMT1NFJzonTUVOVSd9O3dpbmRvdy5kZ3NTdmM9ZnVuY3Rpb24oKXt2YXIgaXRlbT1kb2N1bWVudC5nZXRFbGVtZW50QnlJZCgnZGdzU3ZjSXRlbScpO3ZhciBzdWI9ZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ2Rnc1N1YicpO2lmKCFpdGVtfHwhc3ViKXJldHVybjt2YXIgb3BlbmluZz0haXRlbS5jbGFzc0xpc3QuY29udGFpbnMoJ3N2Yy1vcGVuJyk7aXRlbS5jbGFzc0xpc3QudG9nZ2xlKCdzdmMtb3Blbicsb3BlbmluZyk7c3ViLmNsYXNzTGlzdC50b2dnbGUoJ29wZW4nLG9wZW5pbmcpfTtkb2N1bWVudC5hZGRFdmVudExpc3RlbmVyKCdjbGljaycsZnVuY3Rpb24oZSl7dmFyIGVsPWUudGFyZ2V0LmNsb3Nlc3QoJy5kZy1ubCcpO2lmKGVsKXt2YXIgbmF2PWRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCdkZ3NOYXYnKTt2YXIgbGFiZWw9ZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ2Rnc1RyaWdMYWJlbCcpO2lmKG5hdiYmbmF2LmNsYXNzTGlzdC5jb250YWlucygnbmF2LW9wZW4nKSl7bmF2LmNsYXNzTGlzdC5yZW1vdmUoJ25hdi1vcGVuJyk7d2luZG93LmRnc1VubG9ja1Njcm9sbCgpfQppZihsYWJlbClsYWJlbC50ZXh0Q29udGVudD0nTUVOVSd9fSk7d2luZG93LmFkZEV2ZW50TGlzdGVuZXIoJ3Njcm9sbCcsZnVuY3Rpb24oKXt2YXIgYmFyPWRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCdkZ3NCYXInKTtpZihiYXIpYmFyLmNsYXNzTGlzdC50b2dnbGUoJ3Njcm9sbGVkJyx3aW5kb3cuc2Nyb2xsWT40MCk7fSx7cGFzc2l2ZTohMH0pO3dpbmRvdy5kZ3NPcGVuVGFsa1BvcHVwPWZ1bmN0aW9uKGV2ZW50KXtpZihldmVudClldmVudC5wcmV2ZW50RGVmYXVsdCgpO3ZhciBwb3B1cD1kb2N1bWVudC5nZXRFbGVtZW50QnlJZCgnZGdzVGFsa1BvcHVwJyk7dmFyIG5hdj1kb2N1bWVudC5nZXRFbGVtZW50QnlJZCgnZGdzTmF2Jyk7dmFyIGxhYmVsPWRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCdkZ3NUcmlnTGFiZWwnKTtpZighcG9wdXApcmV0dXJuO2lmKG5hdiYmbmF2LmNsYXNzTGlzdC5jb250YWlucygnbmF2LW9wZW4nKSl7bmF2LmNsYXNzTGlzdC5yZW1vdmUoJ25hdi1vcGVuJyk7aWYobGFiZWwpbGFiZWwudGV4dENvbnRlbnQ9J01FTlUnO3dpbmRvdy5kZ3NVbmxvY2tTY3JvbGwoKX0KcG9wdXAuY2xhc3NMaXN0LmFkZCgnaXMtb3BlbicpO3BvcHVwLnNldEF0dHJpYnV0ZSgnYXJpYS1oaWRkZW4nLCdmYWxzZScpO2RvY3VtZW50LmRvY3VtZW50RWxlbWVudC5jbGFzc0xpc3QuYWRkKCdkZ3MtdGFsay1wb3B1cC1hY3RpdmUnKTtkb2N1bWVudC5ib2R5LmNsYXNzTGlzdC5hZGQoJ2Rncy10YWxrLXBvcHVwLWFjdGl2ZScpO3ZhciBmaXJzdEZpZWxkPXBvcHVwLnF1ZXJ5U2VsZWN0b3IoJ2lucHV0LCB0ZXh0YXJlYSwgc2VsZWN0Jyk7aWYoZmlyc3RGaWVsZCl7c2V0VGltZW91dChmdW5jdGlvbigpe2ZpcnN0RmllbGQuZm9jdXMoKX0sMTgwKX19O3dpbmRvdy5kZ3NDbG9zZVRhbGtQb3B1cD1mdW5jdGlvbigpe3ZhciBwb3B1cD1kb2N1bWVudC5nZXRFbGVtZW50QnlJZCgnZGdzVGFsa1BvcHVwJyk7aWYoIXBvcHVwKXJldHVybjtwb3B1cC5jbGFzc0xpc3QucmVtb3ZlKCdpcy1vcGVuJyk7cG9wdXAuc2V0QXR0cmlidXRlKCdhcmlhLWhpZGRlbicsJ3RydWUnKTtkb2N1bWVudC5kb2N1bWVudEVsZW1lbnQuY2xhc3NMaXN0LnJlbW92ZSgnZGdzLXRhbGstcG9wdXAtYWN0aXZlJyk7ZG9jdW1lbnQuYm9keS5jbGFzc0xpc3QucmVtb3ZlKCdkZ3MtdGFsay1wb3B1cC1hY3RpdmUnKX07ZG9jdW1lbnQuYWRkRXZlbnRMaXN0ZW5lcignY2xpY2snLGZ1bmN0aW9uKGUpe3ZhciB0YWxrVHJpZ2dlcj1lLnRhcmdldC5jbG9zZXN0KCcuZGdzLXRhbGstdHJpZ2dlcicpO3ZhciB0YWxrQ2xvc2U9ZS50YXJnZXQuY2xvc2VzdCgnW2RhdGEtZGdzLXRhbGstY2xvc2VdJyk7aWYodGFsa1RyaWdnZXIpe3dpbmRvdy5kZ3NPcGVuVGFsa1BvcHVwKGUpfQppZih0YWxrQ2xvc2Upe3dpbmRvdy5kZ3NDbG9zZVRhbGtQb3B1cCgpfX0pO2RvY3VtZW50LmFkZEV2ZW50TGlzdGVuZXIoJ2tleWRvd24nLGZ1bmN0aW9uKGUpe2lmKGUua2V5PT09J0VzY2FwZScpe3dpbmRvdy5kZ3NDbG9zZVRhbGtQb3B1cCgpO3ZhciBuYXY9ZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ2Rnc05hdicpO3ZhciBsYWJlbD1kb2N1bWVudC5nZXRFbGVtZW50QnlJZCgnZGdzVHJpZ0xhYmVsJyk7aWYobmF2JiZuYXYuY2xhc3NMaXN0LmNvbnRhaW5zKCduYXYtb3BlbicpKXtuYXYuY2xhc3NMaXN0LnJlbW92ZSgnbmF2LW9wZW4nKTt3aW5kb3cuZGdzVW5sb2NrU2Nyb2xsKCk7aWYobGFiZWwpbGFiZWwudGV4dENvbnRlbnQ9J01FTlUnfX19KQ==" defer></script> </div></div></header>`}})]})}])},56063,a=>{"use strict";var b=a.i(87924);a.i(72131),a.s(["default",0,function(){return(0,b.jsxs)(b.Fragment,{children:[(0,b.jsx)("style",{dangerouslySetInnerHTML:{__html:`/* ========================================
   FOOTER - LIGHTWEIGHT & SEXY DESIGN
   ======================================== */

.dgs-footer-wrapper * {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
}

.dgs-footer-wrapper {
  position: relative;
  background: transparent;
  padding: 0;
  margin: 0;
  font-family: 'Space Grotesk', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
  overflow: hidden;
}

.dgs-footer {
  position: relative;
  background: transparent;
  border-top: 1px solid rgba(255, 255, 255, 0.05);
  padding: clamp(60px, 8vw, 100px) clamp(20px, 4vw, 40px) 0;
  color: #fff;
  overflow: hidden;
}

.dgs-footer-container {
  max-width: 1600px;
  margin: 0 auto;
  position: relative;
  z-index: 2;
}

.dgs-footer-grid {
  display: grid;
  grid-template-columns: 1.2fr repeat(3, 1fr);
  gap: clamp(30px, 4vw, 40px);
  margin-bottom: clamp(40px, 5vw, 55px);
}

.dgs-footer-column {
  display: flex;
  flex-direction: column;
}

.dgs-footer-logo-column {
  max-width: 280px;
}

.dgs-footer-logo {
  display: block;
  width: clamp(130px, 15vw, 160px);
  height: auto;
  margin-bottom: 22px;
  transition: transform 0.4s ease;
  opacity: 0.95;
}

.dgs-footer-logo:hover {
  transform: scale(1.03);
  opacity: 1;
}

.dgs-footer-tagline {
  font-size: clamp(0.8rem, 1.2vw, 0.88rem);
  font-weight: 300;
  color: rgba(255, 255, 255, 0.5);
  letter-spacing: 0.3px;
  margin-top: 0;
  margin-bottom: 22px;
  line-height: 1.7;
}

.dgs-footer-column-title {
  font-size: clamp(0.95rem, 1.5vw, 1.1rem);
  font-weight: 400;
  color: rgba(255, 255, 255, 0.95);
  margin-bottom: clamp(16px, 2vw, 20px);
  letter-spacing: 0.5px;
  position: relative;
  display: inline-block;
  width: fit-content;
}

.dgs-footer-column-title::after {
  content: '';
  position: absolute;
  bottom: -6px;
  left: 0;
  width: 30px;
  height: 1px;
  background: linear-gradient(90deg, #00D4FF 0%, #FF00DC 50%, #FF6B35 100%);
  border-radius: 10px;
  opacity: 0.6;
}

.dgs-footer-links {
  list-style: none;
  padding: 0;
  margin: 0;
}

.dgs-footer-link-item {
  margin-bottom: 8px;
}

.dgs-footer-link {
  display: inline-block;
  font-size: clamp(0.82rem, 1.2vw, 0.9rem);
  font-weight: 300;
  color: rgba(255, 255, 255, 0.55);
  text-decoration: none;
  transition: all 0.3s ease;
  position: relative;
  padding-left: 0;
  letter-spacing: 0.3px;
}

.dgs-footer-link::before {
  content: '→';
  position: absolute;
  left: -18px;
  opacity: 0;
  color: #FF6B35;
  transition: all 0.3s ease;
  font-weight: 300;
}

.dgs-footer-link:hover {
  color: rgba(255, 255, 255, 0.95);
  padding-left: 18px;
}

.dgs-footer-link:hover::before {
  opacity: 1;
  left: 0;
}

.dgs-footer-contact-item {
  display: flex;
  align-items: flex-start;
  gap: 10px;
  margin-bottom: 14px;
  font-size: clamp(0.82rem, 1.2vw, 0.9rem);
  font-weight: 300;
  color: rgba(255, 255, 255, 0.65);
  line-height: 1.7;
}

.dgs-footer-contact-item div {
  text-align: left;
}

.dgs-footer-contact-icon {
  flex-shrink: 0;
  width: 18px;
  height: 18px;
  margin-top: 3px;
  opacity: 1;
  background: transparent !important;
}

.dgs-footer-contact-icon path {
  fill: none !important;
  background: none !important;
}

.dgs-footer-contact-item strong {
  font-weight: 400;
  color: rgba(255, 255, 255, 0.85);
}

.dgs-footer-contact-link {
  color: rgba(255, 255, 255, 0.65);
  text-decoration: none;
  transition: all 0.3s ease;
  display: block;
  margin-bottom: 6px;
  font-weight: 300;
}

.dgs-footer-contact-link:hover {
  color: rgba(255, 255, 255, 0.95);
  padding-left: 6px;
}

.dgs-footer-map-container {
  margin-top: 12px;
  max-height: 0;
  overflow: hidden;
  opacity: 0;
  transition: all 0.5s ease;
  border-radius: 12px;
}

.dgs-footer-map-container.active {
  max-height: 350px;
  opacity: 1;
  margin-top: 16px;
}

.dgs-footer-map-container iframe {
  width: 100%;
  height: 300px;
  border: 0;
  border-radius: 12px;
  display: block;
}

.dgs-footer-address-clickable {
  cursor: pointer;
  transition: all 0.3s ease;
}

.dgs-footer-address-clickable:hover {
  color: rgba(255, 255, 255, 0.95);
}

.dgs-footer-address-clickable strong {
  position: relative;
  display: inline-block;
}

.dgs-footer-address-clickable strong::after {
  content: ' ↗';
  font-size: 0.85em;
  opacity: 0.6;
  transition: all 0.3s ease;
}

.dgs-footer-address-clickable:hover strong::after {
  opacity: 1;
  transform: translateX(2px) translateY(-2px);
}

.dgs-footer-social {
  display: flex;
  gap: 12px;
  flex-wrap: wrap;
  margin-top: 0;
}

.dgs-footer-social-link {
  display: flex;
  align-items: center;
  justify-content: center;
  width: 40px;
  height: 40px;
  background: transparent;
  border: 1px solid rgba(255, 255, 255, 0.15);
  border-radius: 10px;
  color: rgba(255, 255, 255, 0.6);
  text-decoration: none;
  transition: all 0.4s ease;
}

.dgs-footer-social-link:hover {
  background: transparent;
  border-color: rgba(255, 107, 53, 0.5);
  transform: translateY(-3px);
  box-shadow: 0 6px 20px rgba(255, 107, 53, 0.15);
  color: rgba(255, 255, 255, 0.95);
}

.dgs-footer-social-icon {
  width: 18px;
  height: 18px;
}

.dgs-footer-stalk-box {
  margin-top: 18px;
  width: 100%;
}

.dgs-footer-stalk-title {
  font-size: clamp(0.82rem, 1.2vw, 0.92rem);
  font-weight: 500;
  color: rgba(255, 255, 255, 0.82);
  letter-spacing: 0.3px;
  margin-bottom: 12px;
  line-height: 1.35;
}

.dgs-footer-contact-column .dgs-footer-social {
  justify-content: flex-start;
}

.dgs-footer-contact-column .dgs-footer-social-link {
  width: 38px;
  height: 38px;
  border-radius: 10px;
  background: rgba(255, 255, 255, 0.035);
}

/* AI Summary Shortcut Icons - Latest Brand Icons */
.dgs-footer-ai-summary {
  margin: 0 0 22px;
  width: 100%;
}

.dgs-footer-ai-heading {
  font-size: clamp(0.76rem, 1.1vw, 0.84rem);
  font-weight: 400;
  color: rgba(255, 255, 255, 0.72);
  letter-spacing: 0.25px;
  margin-bottom: 10px;
  line-height: 1.45;
}

.dgs-footer-ai-icons {
  display: flex;
  align-items: center;
  gap: 10px;
  flex-wrap: wrap;
}

.dgs-footer-ai-link {
  width: 36px;
  height: 36px;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  border-radius: 10px;
  border: 1px solid rgba(255, 255, 255, 0.16);
  background: rgba(255, 255, 255, 0.065);
  text-decoration: none;
  transition: all 0.35s ease;
  position: relative;
  overflow: hidden;
  backdrop-filter: blur(8px);
  -webkit-backdrop-filter: blur(8px);
}

.dgs-footer-ai-link::before {
  content: '';
  position: absolute;
  inset: 0;
  background: linear-gradient(135deg, rgba(0, 212, 255, 0.18), rgba(255, 0, 220, 0.14), rgba(255, 107, 53, 0.18));
  opacity: 0;
  transition: opacity 0.35s ease;
}

.dgs-footer-ai-link:hover {
  transform: translateY(-3px);
  border-color: rgba(255, 107, 53, 0.55);
  box-shadow: 0 8px 24px rgba(255, 107, 53, 0.18);
}

.dgs-footer-ai-link:hover::before {
  opacity: 1;
}

.dgs-footer-ai-icon {
  position: relative;
  z-index: 1;
  width: 19px;
  height: 19px;
  display: block;
  object-fit: contain;
  filter: drop-shadow(0 2px 4px rgba(0, 0, 0, 0.22));
}

.dgs-footer-ai-fallback {
  position: relative;
  z-index: 1;
  display: none;
  align-items: center;
  justify-content: center;
  width: 100%;
  height: 100%;
  color: rgba(255, 255, 255, 0.92);
  font-size: 0.68rem;
  font-weight: 700;
  line-height: 1;
  letter-spacing: 0.2px;
}

.dgs-ai-prompt-toast {
  position: fixed;
  left: 50%;
  bottom: 24px;
  transform: translateX(-50%) translateY(20px);
  z-index: 999999;
  max-width: min(92vw, 420px);
  padding: 12px 16px;
  border-radius: 14px;
  background: rgba(10, 10, 14, 0.92);
  border: 1px solid rgba(255, 255, 255, 0.14);
  box-shadow: 0 14px 40px rgba(0, 0, 0, 0.35);
  color: rgba(255, 255, 255, 0.92);
  font-size: 0.82rem;
  line-height: 1.45;
  opacity: 0;
  pointer-events: none;
  transition: opacity 0.28s ease, transform 0.28s ease;
  backdrop-filter: blur(14px);
  -webkit-backdrop-filter: blur(14px);
}

.dgs-ai-prompt-toast.active {
  opacity: 1;
  transform: translateX(-50%) translateY(0);
}


.dgs-footer-ai-top {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 16px;
  flex-wrap: wrap;
  margin: 0 0 clamp(32px, 4vw, 45px);
  padding: 16px 20px;
  border-radius: 18px;
  background: rgba(255, 255, 255, 0.045);
  border: 1px solid rgba(255, 255, 255, 0.11);
  box-shadow: 0 14px 38px rgba(0, 0, 0, 0.18);
}

.dgs-footer-ai-top .dgs-footer-ai-heading {
  margin-bottom: 0;
  text-align: center;
}


.dgs-footer-trust-badges {
  display: flex;
  align-items: center;
  gap: 12px;
  flex-wrap: wrap;
  margin: 8px 0 22px;
}

.dgs-footer-trust-badge {
  display: inline-flex;
  align-items: center;
  gap: 12px;
  width: fit-content;
  max-width: 100%;
  min-height: 58px;
  padding: 9px 14px 9px 10px;
  border-radius: 14px;
  background: rgba(255, 255, 255, 0.055);
  border: 1px solid rgba(255, 255, 255, 0.14);
  box-shadow: 0 10px 28px rgba(0, 0, 0, 0.18);
  transition: all 0.35s ease;
}

.dgs-footer-trust-badge:hover {
  transform: translateY(-2px);
  border-color: rgba(255, 107, 53, 0.45);
  box-shadow: 0 12px 30px rgba(255, 107, 53, 0.18);
}

.dgs-footer-trust-logo-wrap {
  display: flex;
  align-items: center;
  justify-content: center;
  width: 74px;
  height: 42px;
  padding: 4px 6px;
  border-radius: 10px;
  background: #ffffff;
  overflow: hidden;
  flex-shrink: 0;
}

.dgs-footer-trust-logo-wrap img {
  display: block;
  width: 100%;
  height: 100%;
  object-fit: contain;
}

.dgs-footer-trust-copy {
  display: flex;
  flex-direction: column;
  justify-content: center;
  line-height: 1.15;
  text-align: left;
}

.dgs-footer-trust-title {
  font-size: 0.78rem;
  font-weight: 600;
  color: rgba(255, 255, 255, 0.96);
  letter-spacing: 0.2px;
  margin-bottom: 3px;
}

.dgs-footer-trust-stars {
  font-size: 0.82rem;
  font-weight: 500;
  color: #ff6b35;
  letter-spacing: 0.8px;
  margin-bottom: 3px;
}

.dgs-footer-trust-subtext {
  font-size: 0.68rem;
  font-weight: 300;
  color: rgba(255, 255, 255, 0.58);
  letter-spacing: 0.25px;
}

.dgs-footer-bottom {
  border-top: 1px solid rgba(255, 255, 255, 0.05);
  padding: clamp(20px, 3vw, 28px) 0;
  text-align: center;
}

.dgs-footer-copyright {
  font-size: clamp(0.75rem, 1.2vw, 0.85rem);
  font-weight: 300;
  color: rgba(255, 255, 255, 0.45);
  letter-spacing: 0.5px;
  margin-bottom: 10px;
}

.dgs-footer-copyright-gradient {
  background: linear-gradient(90deg, #00D4FF 0%, #FF00DC 50%, #FF6B35 100%);
  background-size: 200% 100%;
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  background-clip: text;
  animation: gradientSlideFooter 8s linear infinite;
  font-weight: 400;
}

.dgs-footer-legal-links {
  display: flex;
  justify-content: center;
  align-items: center;
  gap: 20px;
  flex-wrap: wrap;
}

.dgs-footer-legal-link {
  font-size: clamp(0.75rem, 1.2vw, 0.82rem);
  font-weight: 300;
  color: rgba(255, 255, 255, 0.45);
  text-decoration: none;
  transition: all 0.3s ease;
  letter-spacing: 0.3px;
}

.dgs-footer-legal-link:hover {
  color: rgba(255, 255, 255, 0.85);
}

.dgs-footer-legal-divider {
  color: rgba(255, 255, 255, 0.25);
  font-weight: 300;
}

@keyframes gradientSlideFooter {
  0% { background-position: 0% 50%; }
  100% { background-position: 200% 50%; }
}

@media (max-width: 1100px) {
  .dgs-footer-grid {
    grid-template-columns: repeat(2, 1fr);
    gap: clamp(28px, 4vw, 35px);
  }

  .dgs-footer-trust-badges {
    justify-content: center;
  }

  .dgs-footer-logo-column {
    grid-column: 1 / -1;
    max-width: 100%;
    text-align: center;
    align-items: center;
  }

  .dgs-footer-logo {
    margin-left: auto;
    margin-right: auto;
  }

  .dgs-footer-social {
    justify-content: center;
  }

  .dgs-footer-ai-summary {
    text-align: center;
  }

  .dgs-footer-ai-icons {
    justify-content: center;
  }
}

@media (max-width: 968px) {
  .dgs-footer {
    padding: clamp(50px, 7vw, 70px) clamp(20px, 4vw, 30px) 0 !important;
  }

  .dgs-footer-grid {
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap: 30px;
  }

  .dgs-footer-column {
    text-align: center;
    align-items: center;
  }

  .dgs-footer-column-title::after {
    left: 50%;
    transform: translateX(-50%);
  }

  .dgs-footer-link::before {
    display: none;
  }

  .dgs-footer-link:hover {
    padding-left: 0;
  }

  .dgs-footer-contact-item {
    flex-direction: column;
    align-items: center;
    text-align: center;
    gap: 8px;
  }

  .dgs-footer-contact-item div {
    text-align: center;
  }

  .dgs-footer-contact-icon {
    margin-top: 0;
  }

  .dgs-footer-social {
    justify-content: center;
  }
}


  .dgs-footer-contact-column .dgs-footer-social {
    justify-content: center;
  }

  .dgs-footer-stalk-box {
    text-align: center;
  }

@media (max-width: 580px) {
  .dgs-footer {
    padding: 45px 20px 0 !important;
  }

  .dgs-footer-trust-badges {
    justify-content: center;
    gap: 10px;
    margin-bottom: 20px;
  }

  .dgs-footer-trust-badge {
    padding: 9px 12px 9px 9px;
    gap: 10px;
  }

  .dgs-footer-trust-logo-wrap {
    width: 68px;
    height: 40px;
  }

  .dgs-footer-trust-title {
    font-size: 0.74rem;
  }

  .dgs-footer-trust-stars {
    font-size: 0.78rem;
  }

  .dgs-footer-trust-subtext {
    font-size: 0.64rem;
  }

  .dgs-footer-grid {
    grid-template-columns: 1fr;
    gap: 28px;
  }

  .dgs-footer-legal-links {
    flex-direction: column;
    gap: 10px;
  }

  .dgs-footer-legal-divider {
    display: none;
  }



  .dgs-footer-ai-top {
    flex-direction: column;
    gap: 12px;
    margin-bottom: 30px;
    padding: 16px;
  }
  .dgs-footer-map-container iframe {
    height: 250px;
  }
}`}}),(0,b.jsx)("div",{dangerouslySetInnerHTML:{__html:`<footer data-elementor-type="footer" data-elementor-id="61373" class="elementor elementor-61373 elementor-location-footer" data-elementor-post-type="elementor_library"><div class="elementor-element elementor-element-2efa958a e-con-full e-flex cmsmasters-block-default e-con e-parent" data-id="2efa958a" data-element_type="container" data-e-type="container"><div class="elementor-element elementor-element-7c4676d cmsmasters-block-default cmsmasters-sticky-default elementor-widget elementor-widget-html" data-id="7c4676d" data-element_type="widget" data-e-type="widget" data-widget_type="html.default"><style>/* ========================================
   FOOTER - LIGHTWEIGHT & SEXY DESIGN
   ======================================== */

.dgs-footer-wrapper * {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
}

.dgs-footer-wrapper {
  position: relative;
  background: transparent;
  padding: 0;
  margin: 0;
  font-family: 'Space Grotesk', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
  overflow: hidden;
}

.dgs-footer {
  position: relative;
  background: transparent;
  border-top: 1px solid rgba(255, 255, 255, 0.05);
  padding: clamp(60px, 8vw, 100px) clamp(20px, 4vw, 40px) 0;
  color: #fff;
  overflow: hidden;
}

.dgs-footer-container {
  max-width: 1600px;
  margin: 0 auto;
  position: relative;
  z-index: 2;
}

.dgs-footer-grid {
  display: grid;
  grid-template-columns: 1.2fr repeat(3, 1fr);
  gap: clamp(30px, 4vw, 40px);
  margin-bottom: clamp(40px, 5vw, 55px);
}

.dgs-footer-column {
  display: flex;
  flex-direction: column;
}

.dgs-footer-logo-column {
  max-width: 280px;
}

.dgs-footer-logo {
  display: block;
  width: clamp(130px, 15vw, 160px);
  height: auto;
  margin-bottom: 22px;
  transition: transform 0.4s ease;
  opacity: 0.95;
}

.dgs-footer-logo:hover {
  transform: scale(1.03);
  opacity: 1;
}

.dgs-footer-tagline {
  font-size: clamp(0.8rem, 1.2vw, 0.88rem);
  font-weight: 300;
  color: rgba(255, 255, 255, 0.5);
  letter-spacing: 0.3px;
  margin-top: 0;
  margin-bottom: 22px;
  line-height: 1.7;
}

.dgs-footer-column-title {
  font-size: clamp(0.95rem, 1.5vw, 1.1rem);
  font-weight: 400;
  color: rgba(255, 255, 255, 0.95);
  margin-bottom: clamp(16px, 2vw, 20px);
  letter-spacing: 0.5px;
  position: relative;
  display: inline-block;
  width: fit-content;
}

.dgs-footer-column-title::after {
  content: '';
  position: absolute;
  bottom: -6px;
  left: 0;
  width: 30px;
  height: 1px;
  background: linear-gradient(90deg, #00D4FF 0%, #FF00DC 50%, #FF6B35 100%);
  border-radius: 10px;
  opacity: 0.6;
}

.dgs-footer-links {
  list-style: none;
  padding: 0;
  margin: 0;
}

.dgs-footer-link-item {
  margin-bottom: 8px;
}

.dgs-footer-link {
  display: inline-block;
  font-size: clamp(0.82rem, 1.2vw, 0.9rem);
  font-weight: 300;
  color: rgba(255, 255, 255, 0.55);
  text-decoration: none;
  transition: all 0.3s ease;
  position: relative;
  padding-left: 0;
  letter-spacing: 0.3px;
}

.dgs-footer-link::before {
  content: '→';
  position: absolute;
  left: -18px;
  opacity: 0;
  color: #FF6B35;
  transition: all 0.3s ease;
  font-weight: 300;
}

.dgs-footer-link:hover {
  color: rgba(255, 255, 255, 0.95);
  padding-left: 18px;
}

.dgs-footer-link:hover::before {
  opacity: 1;
  left: 0;
}

.dgs-footer-contact-item {
  display: flex;
  align-items: flex-start;
  gap: 10px;
  margin-bottom: 14px;
  font-size: clamp(0.82rem, 1.2vw, 0.9rem);
  font-weight: 300;
  color: rgba(255, 255, 255, 0.65);
  line-height: 1.7;
}

.dgs-footer-contact-item div {
  text-align: left;
}

.dgs-footer-contact-icon {
  flex-shrink: 0;
  width: 18px;
  height: 18px;
  margin-top: 3px;
  opacity: 1;
  background: transparent !important;
}

.dgs-footer-contact-icon path {
  fill: none !important;
  background: none !important;
}

.dgs-footer-contact-item strong {
  font-weight: 400;
  color: rgba(255, 255, 255, 0.85);
}

.dgs-footer-contact-link {
  color: rgba(255, 255, 255, 0.65);
  text-decoration: none;
  transition: all 0.3s ease;
  display: block;
  margin-bottom: 6px;
  font-weight: 300;
}

.dgs-footer-contact-link:hover {
  color: rgba(255, 255, 255, 0.95);
  padding-left: 6px;
}

.dgs-footer-map-container {
  margin-top: 12px;
  max-height: 0;
  overflow: hidden;
  opacity: 0;
  transition: all 0.5s ease;
  border-radius: 12px;
}

.dgs-footer-map-container.active {
  max-height: 350px;
  opacity: 1;
  margin-top: 16px;
}

.dgs-footer-map-container iframe {
  width: 100%;
  height: 300px;
  border: 0;
  border-radius: 12px;
  display: block;
}

.dgs-footer-address-clickable {
  cursor: pointer;
  transition: all 0.3s ease;
}

.dgs-footer-address-clickable:hover {
  color: rgba(255, 255, 255, 0.95);
}

.dgs-footer-address-clickable strong {
  position: relative;
  display: inline-block;
}

.dgs-footer-address-clickable strong::after {
  content: ' ↗';
  font-size: 0.85em;
  opacity: 0.6;
  transition: all 0.3s ease;
}

.dgs-footer-address-clickable:hover strong::after {
  opacity: 1;
  transform: translateX(2px) translateY(-2px);
}

.dgs-footer-social {
  display: flex;
  gap: 12px;
  flex-wrap: wrap;
  margin-top: 0;
}

.dgs-footer-social-link {
  display: flex;
  align-items: center;
  justify-content: center;
  width: 40px;
  height: 40px;
  background: transparent;
  border: 1px solid rgba(255, 255, 255, 0.15);
  border-radius: 10px;
  color: rgba(255, 255, 255, 0.6);
  text-decoration: none;
  transition: all 0.4s ease;
}

.dgs-footer-social-link:hover {
  background: transparent;
  border-color: rgba(255, 107, 53, 0.5);
  transform: translateY(-3px);
  box-shadow: 0 6px 20px rgba(255, 107, 53, 0.15);
  color: rgba(255, 255, 255, 0.95);
}

.dgs-footer-social-icon {
  width: 18px;
  height: 18px;
}

.dgs-footer-stalk-box {
  margin-top: 18px;
  width: 100%;
}

.dgs-footer-stalk-title {
  font-size: clamp(0.82rem, 1.2vw, 0.92rem);
  font-weight: 500;
  color: rgba(255, 255, 255, 0.82);
  letter-spacing: 0.3px;
  margin-bottom: 12px;
  line-height: 1.35;
}

.dgs-footer-contact-column .dgs-footer-social {
  justify-content: flex-start;
}

.dgs-footer-contact-column .dgs-footer-social-link {
  width: 38px;
  height: 38px;
  border-radius: 10px;
  background: rgba(255, 255, 255, 0.035);
}

/* AI Summary Shortcut Icons - Latest Brand Icons */
.dgs-footer-ai-summary {
  margin: 0 0 22px;
  width: 100%;
}

.dgs-footer-ai-heading {
  font-size: clamp(0.76rem, 1.1vw, 0.84rem);
  font-weight: 400;
  color: rgba(255, 255, 255, 0.72);
  letter-spacing: 0.25px;
  margin-bottom: 10px;
  line-height: 1.45;
}

.dgs-footer-ai-icons {
  display: flex;
  align-items: center;
  gap: 10px;
  flex-wrap: wrap;
}

.dgs-footer-ai-link {
  width: 36px;
  height: 36px;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  border-radius: 10px;
  border: 1px solid rgba(255, 255, 255, 0.16);
  background: rgba(255, 255, 255, 0.065);
  text-decoration: none;
  transition: all 0.35s ease;
  position: relative;
  overflow: hidden;
  backdrop-filter: blur(8px);
  -webkit-backdrop-filter: blur(8px);
}

.dgs-footer-ai-link::before {
  content: '';
  position: absolute;
  inset: 0;
  background: linear-gradient(135deg, rgba(0, 212, 255, 0.18), rgba(255, 0, 220, 0.14), rgba(255, 107, 53, 0.18));
  opacity: 0;
  transition: opacity 0.35s ease;
}

.dgs-footer-ai-link:hover {
  transform: translateY(-3px);
  border-color: rgba(255, 107, 53, 0.55);
  box-shadow: 0 8px 24px rgba(255, 107, 53, 0.18);
}

.dgs-footer-ai-link:hover::before {
  opacity: 1;
}

.dgs-footer-ai-icon {
  position: relative;
  z-index: 1;
  width: 19px;
  height: 19px;
  display: block;
  object-fit: contain;
  filter: drop-shadow(0 2px 4px rgba(0, 0, 0, 0.22));
}

.dgs-footer-ai-fallback {
  position: relative;
  z-index: 1;
  display: none;
  align-items: center;
  justify-content: center;
  width: 100%;
  height: 100%;
  color: rgba(255, 255, 255, 0.92);
  font-size: 0.68rem;
  font-weight: 700;
  line-height: 1;
  letter-spacing: 0.2px;
}

.dgs-ai-prompt-toast {
  position: fixed;
  left: 50%;
  bottom: 24px;
  transform: translateX(-50%) translateY(20px);
  z-index: 999999;
  max-width: min(92vw, 420px);
  padding: 12px 16px;
  border-radius: 14px;
  background: rgba(10, 10, 14, 0.92);
  border: 1px solid rgba(255, 255, 255, 0.14);
  box-shadow: 0 14px 40px rgba(0, 0, 0, 0.35);
  color: rgba(255, 255, 255, 0.92);
  font-size: 0.82rem;
  line-height: 1.45;
  opacity: 0;
  pointer-events: none;
  transition: opacity 0.28s ease, transform 0.28s ease;
  backdrop-filter: blur(14px);
  -webkit-backdrop-filter: blur(14px);
}

.dgs-ai-prompt-toast.active {
  opacity: 1;
  transform: translateX(-50%) translateY(0);
}


.dgs-footer-ai-top {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 16px;
  flex-wrap: wrap;
  margin: 0 0 clamp(32px, 4vw, 45px);
  padding: 16px 20px;
  border-radius: 18px;
  background: rgba(255, 255, 255, 0.045);
  border: 1px solid rgba(255, 255, 255, 0.11);
  box-shadow: 0 14px 38px rgba(0, 0, 0, 0.18);
}

.dgs-footer-ai-top .dgs-footer-ai-heading {
  margin-bottom: 0;
  text-align: center;
}


.dgs-footer-trust-badges {
  display: flex;
  align-items: center;
  gap: 12px;
  flex-wrap: wrap;
  margin: 8px 0 22px;
}

.dgs-footer-trust-badge {
  display: inline-flex;
  align-items: center;
  gap: 12px;
  width: fit-content;
  max-width: 100%;
  min-height: 58px;
  padding: 9px 14px 9px 10px;
  border-radius: 14px;
  background: rgba(255, 255, 255, 0.055);
  border: 1px solid rgba(255, 255, 255, 0.14);
  box-shadow: 0 10px 28px rgba(0, 0, 0, 0.18);
  transition: all 0.35s ease;
}

.dgs-footer-trust-badge:hover {
  transform: translateY(-2px);
  border-color: rgba(255, 107, 53, 0.45);
  box-shadow: 0 12px 30px rgba(255, 107, 53, 0.18);
}

.dgs-footer-trust-logo-wrap {
  display: flex;
  align-items: center;
  justify-content: center;
  width: 74px;
  height: 42px;
  padding: 4px 6px;
  border-radius: 10px;
  background: #ffffff;
  overflow: hidden;
  flex-shrink: 0;
}

.dgs-footer-trust-logo-wrap img {
  display: block;
  width: 100%;
  height: 100%;
  object-fit: contain;
}

.dgs-footer-trust-copy {
  display: flex;
  flex-direction: column;
  justify-content: center;
  line-height: 1.15;
  text-align: left;
}

.dgs-footer-trust-title {
  font-size: 0.78rem;
  font-weight: 600;
  color: rgba(255, 255, 255, 0.96);
  letter-spacing: 0.2px;
  margin-bottom: 3px;
}

.dgs-footer-trust-stars {
  font-size: 0.82rem;
  font-weight: 500;
  color: #ff6b35;
  letter-spacing: 0.8px;
  margin-bottom: 3px;
}

.dgs-footer-trust-subtext {
  font-size: 0.68rem;
  font-weight: 300;
  color: rgba(255, 255, 255, 0.58);
  letter-spacing: 0.25px;
}

.dgs-footer-bottom {
  border-top: 1px solid rgba(255, 255, 255, 0.05);
  padding: clamp(20px, 3vw, 28px) 0;
  text-align: center;
}

.dgs-footer-copyright {
  font-size: clamp(0.75rem, 1.2vw, 0.85rem);
  font-weight: 300;
  color: rgba(255, 255, 255, 0.45);
  letter-spacing: 0.5px;
  margin-bottom: 10px;
}

.dgs-footer-copyright-gradient {
  background: linear-gradient(90deg, #00D4FF 0%, #FF00DC 50%, #FF6B35 100%);
  background-size: 200% 100%;
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  background-clip: text;
  animation: gradientSlideFooter 8s linear infinite;
  font-weight: 400;
}

.dgs-footer-legal-links {
  display: flex;
  justify-content: center;
  align-items: center;
  gap: 20px;
  flex-wrap: wrap;
}

.dgs-footer-legal-link {
  font-size: clamp(0.75rem, 1.2vw, 0.82rem);
  font-weight: 300;
  color: rgba(255, 255, 255, 0.45);
  text-decoration: none;
  transition: all 0.3s ease;
  letter-spacing: 0.3px;
}

.dgs-footer-legal-link:hover {
  color: rgba(255, 255, 255, 0.85);
}

.dgs-footer-legal-divider {
  color: rgba(255, 255, 255, 0.25);
  font-weight: 300;
}

@keyframes gradientSlideFooter {
  0% { background-position: 0% 50%; }
  100% { background-position: 200% 50%; }
}

@media (max-width: 1100px) {
  .dgs-footer-grid {
    grid-template-columns: repeat(2, 1fr);
    gap: clamp(28px, 4vw, 35px);
  }

  .dgs-footer-trust-badges {
    justify-content: center;
  }

  .dgs-footer-logo-column {
    grid-column: 1 / -1;
    max-width: 100%;
    text-align: center;
    align-items: center;
  }

  .dgs-footer-logo {
    margin-left: auto;
    margin-right: auto;
  }

  .dgs-footer-social {
    justify-content: center;
  }

  .dgs-footer-ai-summary {
    text-align: center;
  }

  .dgs-footer-ai-icons {
    justify-content: center;
  }
}

@media (max-width: 968px) {
  .dgs-footer {
    padding: clamp(50px, 7vw, 70px) clamp(20px, 4vw, 30px) 0 !important;
  }

  .dgs-footer-grid {
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap: 30px;
  }

  .dgs-footer-column {
    text-align: center;
    align-items: center;
  }

  .dgs-footer-column-title::after {
    left: 50%;
    transform: translateX(-50%);
  }

  .dgs-footer-link::before {
    display: none;
  }

  .dgs-footer-link:hover {
    padding-left: 0;
  }

  .dgs-footer-contact-item {
    flex-direction: column;
    align-items: center;
    text-align: center;
    gap: 8px;
  }

  .dgs-footer-contact-item div {
    text-align: center;
  }

  .dgs-footer-contact-icon {
    margin-top: 0;
  }

  .dgs-footer-social {
    justify-content: center;
  }
}


  .dgs-footer-contact-column .dgs-footer-social {
    justify-content: center;
  }

  .dgs-footer-stalk-box {
    text-align: center;
  }

@media (max-width: 580px) {
  .dgs-footer {
    padding: 45px 20px 0 !important;
  }

  .dgs-footer-trust-badges {
    justify-content: center;
    gap: 10px;
    margin-bottom: 20px;
  }

  .dgs-footer-trust-badge {
    padding: 9px 12px 9px 9px;
    gap: 10px;
  }

  .dgs-footer-trust-logo-wrap {
    width: 68px;
    height: 40px;
  }

  .dgs-footer-trust-title {
    font-size: 0.74rem;
  }

  .dgs-footer-trust-stars {
    font-size: 0.78rem;
  }

  .dgs-footer-trust-subtext {
    font-size: 0.64rem;
  }

  .dgs-footer-grid {
    grid-template-columns: 1fr;
    gap: 28px;
  }

  .dgs-footer-legal-links {
    flex-direction: column;
    gap: 10px;
  }

  .dgs-footer-legal-divider {
    display: none;
  }



  .dgs-footer-ai-top {
    flex-direction: column;
    gap: 12px;
    margin-bottom: 30px;
    padding: 16px;
  }
  .dgs-footer-map-container iframe {
    height: 250px;
  }
}</style>
<svg width="0" height="0" style="position: absolute;" aria-hidden="true" focusable="false">
<defs>
<linearGradient id="footer-icon-gradient" x1="0%" y1="0%" x2="100%" y2="100%">
<stop offset="0%" style="stop-color:#00D4FF;stop-opacity:1" />
<stop offset="50%" style="stop-color:#FF00DC;stop-opacity:1" />
<stop offset="100%" style="stop-color:#FF6B35;stop-opacity:1" />
</linearGradient>
</defs>
</svg><footer class="dgs-footer-wrapper"><div class="dgs-footer"><div class="dgs-footer-container"><div class="dgs-footer-ai-summary dgs-footer-ai-top" aria-label="Ask AI for summary of D'Genius Solutions"><p class="dgs-footer-ai-heading">Ask AI for summary of D'Genius Solutions:</p><div class="dgs-footer-ai-icons">
<a class="dgs-footer-ai-link" href="#" data-ai-platform="chatgpt" onclick="return dgsRunAiPrompt(event, this);" target="_blank" rel="noopener" aria-label="Ask ChatGPT to summarize D'Genius Solutions" title="Ask ChatGPT">
<img class="dgs-footer-ai-icon" src="https://cdn.simpleicons.org/openai/FFFFFF" alt="ChatGPT" loading="lazy" decoding="async" onerror="this.style.display='none';this.nextElementSibling.style.display='inline-flex';">
<span class="dgs-footer-ai-fallback" aria-hidden="true">GPT</span>
</a><a class="dgs-footer-ai-link" href="#" data-ai-platform="perplexity" onclick="return dgsRunAiPrompt(event, this);" target="_blank" rel="noopener" aria-label="Ask Perplexity to summarize D'Genius Solutions" title="Ask Perplexity">
<img class="dgs-footer-ai-icon" src="https://cdn.simpleicons.org/perplexity/FFFFFF" alt="Perplexity" loading="lazy" decoding="async" onerror="this.style.display='none';this.nextElementSibling.style.display='inline-flex';">
<span class="dgs-footer-ai-fallback" aria-hidden="true">PX</span>
</a><a class="dgs-footer-ai-link" href="#" data-ai-platform="gemini" onclick="return dgsRunAiPrompt(event, this);" target="_blank" rel="noopener" aria-label="Ask Gemini to summarize D'Genius Solutions" title="Ask Gemini">
<img class="dgs-footer-ai-icon" src="https://cdn.simpleicons.org/googlegemini/FFFFFF" alt="Gemini" loading="lazy" decoding="async" onerror="this.style.display='none';this.nextElementSibling.style.display='inline-flex';">
<span class="dgs-footer-ai-fallback" aria-hidden="true">GM</span>
</a><a class="dgs-footer-ai-link" href="#" data-ai-platform="claude" onclick="return dgsRunAiPrompt(event, this);" target="_blank" rel="noopener" aria-label="Ask Claude to summarize D'Genius Solutions" title="Ask Claude">
<img class="dgs-footer-ai-icon" src="https://cdn.simpleicons.org/anthropic/FFFFFF" alt="Claude" loading="lazy" decoding="async" onerror="this.style.display='none';this.nextElementSibling.style.display='inline-flex';">
<span class="dgs-footer-ai-fallback" aria-hidden="true">CL</span>
</a><a class="dgs-footer-ai-link" href="#" data-ai-platform="copilot" onclick="return dgsRunAiPrompt(event, this);" target="_blank" rel="noopener" aria-label="Ask Microsoft Copilot to summarize D'Genius Solutions" title="Ask Copilot">
<img class="dgs-footer-ai-icon" src="https://cdn.simpleicons.org/microsoftcopilot/FFFFFF" alt="Copilot" loading="lazy" decoding="async" onerror="this.style.display='none';this.nextElementSibling.style.display='inline-flex';">
<span class="dgs-footer-ai-fallback" aria-hidden="true">CO</span>
</a></div></div><div class="dgs-footer-grid"><div class="dgs-footer-column dgs-footer-logo-column">
<img src="https://www.dgeniussolutions.com/wp-content/uploads/2026/02/cropped-DGS-LOGO.png" alt="D'Genius Solutions digital marketing agency logo" class="dgs-footer-logo" width="160" height="80" loading="lazy" decoding="async"><p class="dgs-footer-tagline">Your growth-focused digital partner for SEO, AI search, branding, content, social media, websites, and performance-led marketing.</p><div class="dgs-footer-trust-badges" aria-label="D'Genius Solutions Clutch rating proof"><div class="dgs-footer-trust-badge" aria-label="D'Genius Solutions Clutch 5-star rating proof">
<span class="dgs-footer-trust-logo-wrap">
<img width="379" height="283" data-src="https://www.dgeniussolutions.com/wp-content/uploads/2026/06/t_clutch-5-star3208.logowik.com_.webp" alt="Clutch 5-star rating badge" decoding="async" src="data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMSIgaGVpZ2h0PSIxIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjwvc3ZnPg==" class="lazyload" style="--smush-placeholder-width: 379px; --smush-placeholder-aspect-ratio: 379/283;">
</span>
<span class="dgs-footer-trust-copy">
<span class="dgs-footer-trust-title">Clutch Rated</span>
<span class="dgs-footer-trust-stars">★★★★★</span>
<span class="dgs-footer-trust-subtext">Trusted client reviews</span>
</span></div></div></div><div class="dgs-footer-column"><div class="dgs-footer-column-title" role="presentation">Quick Links</div><ul class="dgs-footer-links"><li class="dgs-footer-link-item"><a href="https://www.dgeniussolutions.com/" class="dgs-footer-link">Home</a></li><li class="dgs-footer-link-item"><a href="https://www.dgeniussolutions.com/about-us/" class="dgs-footer-link">About Us</a></li><li class="dgs-footer-link-item"><a href="https://www.dgeniussolutions.com/blogs/" class="dgs-footer-link">Blogs</a></li><li class="dgs-footer-link-item"><a href="https://www.dgeniussolutions.com/career/" class="dgs-footer-link">Career</a></li><li class="dgs-footer-link-item"><a href="https://www.dgeniussolutions.com/portfolio/" class="dgs-footer-link">Portfolio</a></li><li class="dgs-footer-link-item"><a href="https://www.dgeniussolutions.com/contact-us/" class="dgs-footer-link">Contact</a></li></ul></div><div class="dgs-footer-column"><div class="dgs-footer-column-title" role="presentation">Services</div><ul class="dgs-footer-links"><li class="dgs-footer-link-item"><a href="https://www.dgeniussolutions.com/services/seo-services-in-mumbai/" class="dgs-footer-link">SEO Services</a></li><li class="dgs-footer-link-item"><a href="https://www.dgeniussolutions.com/services/website-development-amc/" class="dgs-footer-link">Website Development</a></li><li class="dgs-footer-link-item"><a href="https://www.dgeniussolutions.com/services/social-media-marketing/" class="dgs-footer-link">Social Media Marketing</a></li><li class="dgs-footer-link-item"><a href="https://www.dgeniussolutions.com/services/performance-marketing/" class="dgs-footer-link">Performance Marketing</a></li><li class="dgs-footer-link-item"><a href="https://www.dgeniussolutions.com/services/ai-video-production-agency/" class="dgs-footer-link">AI Video Production</a></li><li class="dgs-footer-link-item"><a href="https://www.dgeniussolutions.com/services/content-creation/" class="dgs-footer-link">Content Creation</a></li><li class="dgs-footer-link-item"><a href="https://www.dgeniussolutions.com/services/branding/" class="dgs-footer-link">Branding</a></li><li class="dgs-footer-link-item"><a href="https://www.dgeniussolutions.com/services/aeo-services-in-mumbai/" class="dgs-footer-link">AEO Services</a></li><li class="dgs-footer-link-item"><a href="https://www.dgeniussolutions.com/services/geo/" class="dgs-footer-link">GEO Services</a></li><li class="dgs-footer-link-item"><a href="https://www.dgeniussolutions.com/services/llm-seo-service/" class="dgs-footer-link">LLM SEO Services</a></li></ul></div><div class="dgs-footer-column dgs-footer-contact-column"><div class="dgs-footer-column-title" role="presentation">Contact Us</div><div class="dgs-footer-contact-item dgs-footer-address-clickable" onclick="toggleFooterMap()">
<svg class="dgs-footer-contact-icon" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
<path d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" stroke="url(#footer-icon-gradient)" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" fill="none"/>
<path d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" stroke="url(#footer-icon-gradient)" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" fill="none"/>
</svg><div>
<strong>The Digital Lab</strong><br>
Unit 202, Amore Edge, Swami Vivekanand Rd,<br>
Govind Dham, Khar West, Mumbai 400052<div class="dgs-footer-map-container" id="footerMapEmbed">
<iframe
data-src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3770.9443055813304!2d72.83493657520516!3d19.06618618213635!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3be7c9bfeca795fd%3A0xa3bda380c79caf89!2sD&#39;Genius%20Solutions!5e0!3m2!1sen!2sin!4v1770902787312!5m2!1sen!2sin"
allowfullscreen=""
referrerpolicy="no-referrer-when-downgrade"
title="D'Genius Solutions Google Map" src="about:blank" class="lazyload" data-load-mode="0">
</iframe></div></div></div><div class="dgs-footer-contact-item">
<svg class="dgs-footer-contact-icon" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
<path d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" stroke="url(#footer-icon-gradient)" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" fill="none"/>
</svg><div>
<a href="tel:+919987922901" class="dgs-footer-contact-link">+91 99879 22901</a>
<a href="tel:+918591950238" class="dgs-footer-contact-link">+91 85919 50238</a></div></div><div class="dgs-footer-contact-item">
<svg class="dgs-footer-contact-icon" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
<path d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" stroke="url(#footer-icon-gradient)" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" fill="none"/>
</svg><div>
<a href="mailto:business@dgeniussolutions.com" class="dgs-footer-contact-link">business@dgeniussolutions.com</a></div></div><div class="dgs-footer-stalk-box" aria-label="D'Genius Solutions social media links"><p class="dgs-footer-stalk-title">Stalk us below</p><div class="dgs-footer-social">
<a href="https://www.linkedin.com/company/d-genius-solutions/" class="dgs-footer-social-link" aria-label="LinkedIn" target="_blank" rel="noopener">
<svg class="dgs-footer-social-icon" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
<path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433c-1.144 0-2.063-.926-2.063-2.065 0-1.138.92-2.063 2.063-2.063 1.14 0 2.064.925 2.064 2.063 0 1.139-.925 2.065-2.064 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z"/>
</svg>
</a><a href="https://www.facebook.com/DGeniussolutions/" class="dgs-footer-social-link" aria-label="Facebook" target="_blank" rel="noopener">
<svg class="dgs-footer-social-icon" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
<path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/>
</svg>
</a><a href="https://www.instagram.com/dgenius_solutions/" class="dgs-footer-social-link" aria-label="Instagram" target="_blank" rel="noopener">
<svg class="dgs-footer-social-icon" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
<path d="M12 0C8.74 0 8.333.015 7.053.072 5.775.132 4.905.333 4.14.63c-.789.306-1.459.717-2.126 1.384S.935 3.35.63 4.14C.333 4.905.131 5.775.072 7.053.012 8.333 0 8.74 0 12s.015 3.667.072 4.947c.06 1.277.261 2.148.558 2.913.306.788.717 1.459 1.384 2.126.667.666 1.336 1.079 2.126 1.384.766.296 1.636.499 2.913.558C8.333 23.988 8.74 24 12 24s3.667-.015 4.947-.072c1.277-.06 2.148-.262 2.913-.558.788-.306 1.459-.718 2.126-1.384.666-.667 1.079-1.335 1.384-2.126.296-.765.499-1.636.558-2.913.06-1.28.072-1.687.072-4.947s-.015-3.667-.072-4.947c-.06-1.277-.262-2.149-.558-2.913-.306-.789-.718-1.459-1.384-2.126C21.319 1.347 20.651.935 19.86.63c-.765-.297-1.636-.499-2.913-.558C15.667.012 15.26 0 12 0zm0 2.16c3.203 0 3.585.016 4.85.071 1.17.055 1.805.249 2.227.415.562.217.96.477 1.382.896.419.42.679.819.896 1.381.164.422.36 1.057.413 2.227.057 1.266.07 1.646.07 4.85s-.015 3.585-.074 4.85c-.061 1.17-.256 1.805-.421 2.227-.224.562-.479.96-.899 1.382-.419.419-.824.679-1.38.896-.42.164-1.065.36-2.235.413-1.274.057-1.649.07-4.859.07-3.211 0-3.586-.015-4.859-.074-1.171-.061-1.816-.256-2.236-.421-.569-.224-.96-.479-1.379-.899-.421-.419-.69-.824-.9-1.38-.165-.42-.359-1.065-.42-2.235-.045-1.26-.061-1.649-.061-4.844 0-3.196.016-3.586.061-4.861.061-1.17.255-1.814.42-2.234.21-.57.479-.96.9-1.381.419-.419.81-.689 1.379-.898.42-.166 1.051-.361 2.221-.421 1.275-.045 1.65-.06 4.859-.06l.045.03zm0 3.678c-3.405 0-6.162 2.76-6.162 6.162 0 3.405 2.76 6.162 6.162 6.162 3.405 0 6.162-2.76 6.162-6.162 0-3.405-2.76-6.162-6.162-6.162zM12 16c-2.21 0-4-1.79-4-4s1.79-4 4-4 4 1.79 4 4-1.79 4-4 4zm7.846-10.405c0 .795-.646 1.44-1.44 1.44-.795 0-1.44-.646-1.44-1.44 0-.794.646-1.439 1.44-1.439.793-.001 1.44.645 1.44 1.439z"/>
</svg>
</a><a href="https://in.pinterest.com/dgeniussolutions/" class="dgs-footer-social-link" aria-label="Pinterest" target="_blank" rel="noopener">
<svg class="dgs-footer-social-icon" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
<path d="M12.017 0C5.396 0 .029 5.367.029 11.987c0 5.079 3.158 9.417 7.618 11.162-.105-.949-.199-2.403.041-3.439.219-.937 1.406-5.957 1.406-5.957s-.359-.72-.359-1.781c0-1.663.967-2.911 2.168-2.911 1.024 0 1.518.769 1.518 1.688 0 1.029-.653 2.567-.992 3.992-.285 1.193.6 2.165 1.775 2.165 2.128 0 3.768-2.245 3.768-5.487 0-2.861-2.063-4.869-5.008-4.869-3.41 0-5.409 2.562-5.409 5.199 0 1.033.394 2.143.889 2.741.099.12.112.225.085.345-.09.375-.293 1.199-.334 1.363-.053.225-.172.271-.401.165-1.495-.69-2.433-2.878-2.433-4.646 0-3.776 2.748-7.252 7.92-7.252 4.158 0 7.392 2.967 7.392 6.923 0 4.135-2.607 7.462-6.233 7.462-1.214 0-2.354-.629-2.758-1.379l-.749 2.848c-.269 1.045-1.004 2.352-1.498 3.146 1.123.345 2.306.535 3.55.535 6.607 0 11.985-5.365 11.985-11.987C23.97 5.39 18.592.026 11.985.026L12.017 0z"/>
</svg>
</a><a href="https://www.youtube.com/@dgeniussolutionspvtltd4060" class="dgs-footer-social-link" aria-label="YouTube" target="_blank" rel="noopener">
<svg class="dgs-footer-social-icon" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
<path d="M23.498 6.186a3.016 3.016 0 0 0-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 0 0 .502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 0 0 2.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 0 0 2.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z"/>
</svg>
</a></div></div></div></div><div class="dgs-footer-bottom"><p class="dgs-footer-copyright">
\xa9 2026 <span class="dgs-footer-copyright-gradient">D'Genius Solutions</span>. All Rights Reserved.</p><div class="dgs-footer-legal-links">
<a href="https://www.dgeniussolutions.com/privacy-policy/" class="dgs-footer-legal-link">Privacy Policy</a>
<span class="dgs-footer-legal-divider">•</span>
<a href="https://www.dgeniussolutions.com/sitemap/" class="dgs-footer-legal-link">Sitemap</a></div></div></div></div></footer>`}})]})}])}];

//# sourceMappingURL=app_components_05zh2b8._.js.map